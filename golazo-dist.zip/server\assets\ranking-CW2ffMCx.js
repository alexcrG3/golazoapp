import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { Menu, User, Trophy, Flame, Crown } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { u as useAuth, g as getSupabaseLeaderboard, A as AppShell, F as Flag } from "./AppShell-B0dxobAF.js";
import { f as fetchRealGroupsAndMatches } from "./api-football-DNOoAqkn.js";
import { u as useSidebar } from "./router-Do2s6XFq.js";
import "react";
import "@supabase/supabase-js";
import "sonner";
import "zod";
function RankingPage() {
  const {
    user,
    profile
  } = useAuth();
  const {
    open: openSidebar
  } = useSidebar();
  const {
    data: apiData
  } = useQuery({
    queryKey: ["realMatchesAndGroups"],
    queryFn: fetchRealGroupsAndMatches,
    retry: 2,
    retryDelay: 2e3,
    staleTime: 0,
    gcTime: 0
  });
  const matchesList = apiData?.matches || [];
  const {
    data: dynamicLeaderboard = []
  } = useQuery({
    queryKey: ["supabaseLeaderboard", matchesList, user?.id],
    queryFn: () => getSupabaseLeaderboard(matchesList, user?.id),
    enabled: matchesList.length > 0
  });
  const [first, second, third, ...rest] = dynamicLeaderboard;
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsxs("header", { className: "px-5 pt-[max(28px,env(safe-area-inset-top))]", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 mb-4", children: [
        /* @__PURE__ */ jsx("button", { onClick: openSidebar, title: "Menú", className: "glass grid h-9 w-9 place-items-center rounded-full hover:bg-white/15 transition", children: /* @__PURE__ */ jsx(Menu, { className: "h-4 w-4 text-white" }) }),
        /* @__PURE__ */ jsx(Link, { to: "/profile", className: "shrink-0 transition active:scale-95", children: user ? /* @__PURE__ */ jsx(Flag, { code: profile?.country_code || "cr", size: 32, className: "ring-2 ring-white/10" }) : /* @__PURE__ */ jsx("div", { className: "grid h-8 w-8 place-items-center rounded-full bg-white/5 border border-white/10 text-white/60", children: /* @__PURE__ */ jsx(User, { className: "h-4 w-4" }) }) })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold uppercase tracking-[0.25em] text-primary block mt-1", children: "Ranking Global" }),
      /* @__PURE__ */ jsx("h1", { className: "font-display mt-1 text-5xl leading-none text-white", children: "Clasificación" }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-white/55", children: dynamicLeaderboard.length > 0 ? `${dynamicLeaderboard.length} pronosticadores compitiendo en la quiniela` : "Compite con tus amigos en la quiniela" })
    ] }),
    dynamicLeaderboard.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "mt-12 px-6 text-center py-16 glass rounded-3xl mx-5 relative overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-transparent to-transparent" }),
      /* @__PURE__ */ jsx(Trophy, { className: "h-12 w-12 text-primary mx-auto opacity-40 animate-pulse mb-4" }),
      /* @__PURE__ */ jsx("p", { className: "font-display text-2xl text-white", children: "Sin Competidores" }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-2 max-w-[240px] mx-auto", children: "No hay jugadores registrados en la base de datos todavía." }),
      /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-widest text-primary font-bold mt-4", children: "¡Sé el primero registrándote en Perfil!" })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("section", { className: "mt-8 px-4", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 items-end gap-3", children: [
        /* @__PURE__ */ jsx(PodiumCard, { player: second, place: 2, height: "h-36" }),
        /* @__PURE__ */ jsx(PodiumCard, { player: first, place: 1, height: "h-44", featured: true }),
        /* @__PURE__ */ jsx(PodiumCard, { player: third, place: 3, height: "h-32" })
      ] }) }),
      rest.length > 0 && /* @__PURE__ */ jsx("section", { className: "mt-8 px-4 mb-6", children: /* @__PURE__ */ jsxs("div", { className: "glass overflow-hidden rounded-3xl", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b border-white/10 px-5 py-3 text-[11px] font-bold uppercase tracking-widest text-white/55", children: [
          /* @__PURE__ */ jsx("span", { children: "Pronosticador" }),
          /* @__PURE__ */ jsx("span", { children: "Puntos" })
        ] }),
        /* @__PURE__ */ jsx("ul", { className: "divide-y divide-white/5", children: rest.map((p) => /* @__PURE__ */ jsxs("li", { className: `flex items-center justify-between px-5 py-3.5 transition ${p.isYou ? "bg-primary/10 ring-1 ring-primary/30" : ""}`, children: [
          /* @__PURE__ */ jsxs("div", { className: "flex min-w-0 items-center gap-3", children: [
            /* @__PURE__ */ jsx("span", { className: `font-display w-6 text-lg ${p.isYou ? "text-primary" : "text-white/40"}`, children: p.rank }),
            /* @__PURE__ */ jsx(Flag, { code: p.country, size: 36 }),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("div", { className: `truncate font-semibold ${p.isYou ? "text-primary" : "text-white"}`, children: p.name }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-[11px] text-white/50", children: [
                /* @__PURE__ */ jsxs("span", { children: [
                  p.accuracy,
                  "% prec."
                ] }),
                p.streak > 0 && /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-0.5 text-[oklch(0.85_0.16_50)]", children: [
                  /* @__PURE__ */ jsx(Flame, { className: "h-3 w-3" }),
                  " ",
                  p.streak
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "font-display text-2xl text-white", children: p.points })
        ] }, p.rank)) })
      ] }) })
    ] })
  ] });
}
function PodiumCard({
  player,
  place,
  height,
  featured
}) {
  const colors = {
    1: "text-gradient-gold",
    2: "text-white/85",
    3: "text-[oklch(0.7_0.12_45)]"
  };
  const isVacant = !player;
  const displayName = player?.name || "Vacante";
  const displayPoints = player?.points !== void 0 ? player.points : "-";
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative", children: [
      featured && /* @__PURE__ */ jsx(Crown, { className: "absolute -top-7 left-1/2 h-6 w-6 -translate-x-1/2 text-[oklch(0.9_0.18_85)] drop-shadow-[0_0_12px_oklch(0.9_0.18_85/0.6)]" }),
      isVacant ? /* @__PURE__ */ jsx("div", { className: `rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/30 text-xs font-bold ${featured ? "h-[72px] w-[72px]" : "h-[56px] w-[56px]"}`, children: "-" }) : /* @__PURE__ */ jsx(Flag, { code: player.country, size: featured ? 72 : 56, className: featured ? "ring-[oklch(0.9_0.18_85/0.7)]" : "" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "text-center w-full px-1", children: [
      /* @__PURE__ */ jsx("div", { className: "truncate text-[11px] font-semibold text-white/70", children: displayName }),
      /* @__PURE__ */ jsx("div", { className: "font-display text-base leading-none text-primary mt-0.5", children: displayPoints })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: `glass relative flex w-full ${height} flex-col items-center justify-end rounded-2xl pb-3
          ${featured ? "neon-glow" : ""}`, children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-x-0 top-0 pitch-lines rounded-t-2xl", style: {
        height: "100%"
      } }),
      /* @__PURE__ */ jsx("span", { className: `font-display relative text-6xl leading-none ${colors[place]}`, children: place })
    ] })
  ] });
}
export {
  RankingPage as component
};
