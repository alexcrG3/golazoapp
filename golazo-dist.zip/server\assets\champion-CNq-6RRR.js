import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Trophy, Search, Check } from "lucide-react";
import { k as useChampion, f as teamByCode, t as teams, A as AppShell, F as Flag, p as predictionsStore } from "./AppShell-B0dxobAF.js";
import "@supabase/supabase-js";
import "sonner";
import "./router-Do2s6XFq.js";
import "@tanstack/react-query";
import "zod";
function ChampionPage() {
  const championCode = useChampion();
  const champion = championCode ? teamByCode(championCode) : null;
  const [query, setQuery] = useState("");
  const [confirming, setConfirming] = useState(null);
  const filtered = teams.filter((t) => t.name.toLowerCase().includes(query.toLowerCase()) || t.short.toLowerCase().includes(query.toLowerCase())).sort((a, b) => a.name.localeCompare(b.name));
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsxs("header", { className: "px-5 pt-[max(28px,env(safe-area-inset-top))]", children: [
      /* @__PURE__ */ jsxs(Link, { to: "/matches", className: "inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-white/60", children: [
        /* @__PURE__ */ jsx(ArrowLeft, { className: "h-3.5 w-3.5" }),
        " Volver"
      ] }),
      /* @__PURE__ */ jsx("span", { className: "mt-3 block text-[11px] font-bold uppercase tracking-[0.25em] text-primary", children: "Predicción Especial · 20 pts" }),
      /* @__PURE__ */ jsx("h1", { className: "font-display mt-1 text-5xl leading-none text-white", children: "Campeón del Mundo" }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-white/55", children: "Elige una de las 48 selecciones que levantará la copa." })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "mt-6 px-4", children: /* @__PURE__ */ jsxs("div", { className: "glass-strong relative overflow-hidden rounded-3xl p-6 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,oklch(0.86_0.22_152/0.18),transparent_60%)]" }),
      /* @__PURE__ */ jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsx("div", { className: "mx-auto grid h-28 w-28 place-items-center rounded-full bg-gradient-to-br from-[oklch(0.9_0.18_85)] to-[oklch(0.65_0.18_60)] shadow-[0_20px_60px_-10px_oklch(0.9_0.18_85/0.5)]", children: /* @__PURE__ */ jsx(Trophy, { className: "h-14 w-14 text-[oklch(0.2_0.05_70)]", strokeWidth: 1.5 }) }),
        /* @__PURE__ */ jsx("div", { className: "mt-5 text-[10px] uppercase tracking-[0.3em] text-white/40", children: "Tu Predicción" }),
        champion ? /* @__PURE__ */ jsxs("div", { className: "mt-3 flex items-center justify-center gap-3", children: [
          /* @__PURE__ */ jsx(Flag, { code: champion.code, size: 48 }),
          /* @__PURE__ */ jsxs("div", { className: "text-left", children: [
            /* @__PURE__ */ jsx("div", { className: "font-display text-3xl text-gradient-gold", children: champion.name }),
            /* @__PURE__ */ jsx("button", { onClick: () => predictionsStore.setChampion(null), className: "text-[11px] font-semibold uppercase tracking-widest text-primary", children: "Cambiar predicción" })
          ] })
        ] }) : /* @__PURE__ */ jsx("div", { className: "mt-3 font-display text-2xl text-white/40", children: "— Sin elegir —" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "mt-6 px-4", children: /* @__PURE__ */ jsxs("div", { className: "glass flex items-center gap-2 rounded-2xl px-4 py-3", children: [
      /* @__PURE__ */ jsx(Search, { className: "h-4 w-4 text-white/40" }),
      /* @__PURE__ */ jsx("input", { value: query, onChange: (e) => setQuery(e.target.value), placeholder: "Buscar selección…", className: "flex-1 bg-transparent text-sm text-white placeholder:text-white/35 focus:outline-none" })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "mt-4 grid grid-cols-2 gap-3 px-4", children: filtered.map((t) => {
      const selected = championCode === t.code;
      const isConfirming = confirming === t.code;
      return /* @__PURE__ */ jsxs("button", { onClick: () => {
        if (isConfirming) {
          predictionsStore.setChampion(t.code);
          setConfirming(null);
        } else {
          setConfirming(t.code);
        }
      }, onBlur: () => setConfirming((c) => c === t.code ? null : c), className: `glass relative flex flex-col items-center gap-2 rounded-2xl p-4 text-center transition active:scale-95 ${selected ? "ring-2 ring-primary neon-glow" : "hover:bg-white/8"}`, children: [
        selected && /* @__PURE__ */ jsx("span", { className: "absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-primary text-primary-foreground", children: /* @__PURE__ */ jsx(Check, { className: "h-3.5 w-3.5" }) }),
        /* @__PURE__ */ jsx(Flag, { code: t.code, size: 56 }),
        /* @__PURE__ */ jsx("div", { className: "font-display text-base leading-tight text-white", children: t.short }),
        /* @__PURE__ */ jsx("div", { className: "text-[10px] uppercase tracking-widest text-white/45", children: t.name }),
        isConfirming && !selected && /* @__PURE__ */ jsx("span", { className: "mt-1 rounded-full bg-primary px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-primary-foreground", children: "Confirmar" })
      ] }, t.code);
    }) }),
    filtered.length === 0 && /* @__PURE__ */ jsx("p", { className: "mt-8 text-center text-sm text-white/45", children: "Sin resultados" })
  ] });
}
export {
  ChampionPage as component
};
