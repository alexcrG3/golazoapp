import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { ArrowLeft, BookOpen, FileText, ShieldCheck, Sparkles, Target, Trophy, Zap } from "lucide-react";
import { A as AppShell } from "./AppShell-B0dxobAF.js";
import { R as Route } from "./router-Do2s6XFq.js";
import "@supabase/supabase-js";
import "sonner";
import "@tanstack/react-query";
import "zod";
function RulesPage() {
  const {
    tab
  } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [activeTab, setActiveTab] = useState(tab);
  useEffect(() => {
    setActiveTab(tab);
  }, [tab]);
  const updateTab = (newTab) => {
    setActiveTab(newTab);
    navigate({
      search: {
        tab: newTab
      }
    });
  };
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsxs("header", { className: "px-5 pt-[max(28px,env(safe-area-inset-top))]", children: [
      /* @__PURE__ */ jsxs(Link, { to: "/profile", className: "inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest text-white/60", children: [
        /* @__PURE__ */ jsx(ArrowLeft, { className: "h-3.5 w-3.5" }),
        " Volver al Perfil"
      ] }),
      /* @__PURE__ */ jsx("span", { className: "mt-3 block text-[11px] font-bold uppercase tracking-[0.25em] text-primary", children: "Información Oficial" }),
      /* @__PURE__ */ jsx("h1", { className: "font-display mt-1 text-5xl leading-none text-white", children: "Reglamento" }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-white/55", children: "Conoce las reglas de la quiniela, puntuaciones y términos legales." })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "mt-6 px-4", children: /* @__PURE__ */ jsxs("div", { className: "flex rounded-2xl bg-white/5 p-1 ring-1 ring-white/10", children: [
      /* @__PURE__ */ jsxs("button", { onClick: () => updateTab("manual"), className: `flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-bold uppercase tracking-wider transition ${activeTab === "manual" ? "bg-white text-black font-extrabold" : "text-white/60 hover:text-white"}`, children: [
        /* @__PURE__ */ jsx(BookOpen, { className: "h-3.5 w-3.5" }),
        " Manual"
      ] }),
      /* @__PURE__ */ jsxs("button", { onClick: () => updateTab("terms"), className: `flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-bold uppercase tracking-wider transition ${activeTab === "terms" ? "bg-white text-black font-extrabold" : "text-white/60 hover:text-white"}`, children: [
        /* @__PURE__ */ jsx(FileText, { className: "h-3.5 w-3.5" }),
        " Términos"
      ] }),
      /* @__PURE__ */ jsxs("button", { onClick: () => updateTab("privacy"), className: `flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-bold uppercase tracking-wider transition ${activeTab === "privacy" ? "bg-white text-black font-extrabold" : "text-white/60 hover:text-white"}`, children: [
        /* @__PURE__ */ jsx(ShieldCheck, { className: "h-3.5 w-3.5" }),
        " Privacidad"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("section", { className: "mt-6 px-4 mb-10", children: [
      activeTab === "manual" && /* @__PURE__ */ jsx(GameManualContent, {}),
      activeTab === "terms" && /* @__PURE__ */ jsx(TermsContent, {}),
      activeTab === "privacy" && /* @__PURE__ */ jsx(PrivacyContent, {})
    ] })
  ] });
}
function GameManualContent() {
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "glass p-5 rounded-3xl relative overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-transparent to-transparent" }),
      /* @__PURE__ */ jsxs("h3", { className: "font-display text-2xl text-white mb-2 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Sparkles, { className: "h-5 w-5 text-primary" }),
        " ¿Cómo Jugar Golazo?"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-white/70 leading-relaxed", children: "Golazo es la quiniela definitiva del Mundial 2026. Predice los marcadores de los partidos, acumula puntos basados en los resultados oficiales de la vida real y asciende en la clasificación global frente a todos los participantes de la plataforma." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "glass p-5 rounded-3xl space-y-4", children: [
      /* @__PURE__ */ jsxs("h3", { className: "font-display text-2xl text-white flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Target, { className: "h-5 w-5 text-primary" }),
        " Sistema de Puntuación"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsx("span", { className: "grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-primary/20 text-primary font-bold text-xs", children: "+3" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-white block text-sm", children: "Marcador Exacto" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-0.5", children: "Acertaste el marcador final exacto de ambos equipos. Por ejemplo, predijiste `2 - 1` y el partido termina `2 - 1`." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsx("span", { className: "grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-primary/10 text-white/80 font-bold text-xs", children: "+1" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-white block text-sm", children: "Resultado / Ganador Correcto" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-0.5", children: "Acertaste al ganador del partido o el empate, pero no los goles exactos. Por ejemplo, predijiste `1 - 0` y el partido termina `3 - 1` (ambos victorias de local)." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsx("span", { className: "grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-white/5 text-white/30 font-bold text-xs", children: "0" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-white block text-sm", children: "Sin Puntos" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-0.5", children: "No acertaste al ganador ni al empate del partido." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3 border-t border-white/10 pt-3", children: [
          /* @__PURE__ */ jsx("span", { className: "grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-[oklch(0.9_0.18_85)] to-[oklch(0.65_0.18_60)] text-black font-extrabold text-xs", children: "+20" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-[oklch(0.9_0.18_85)] block text-sm", children: "Predicción Especial: Campeón del Mundo" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-0.5", children: "Elige al equipo que levantará la copa del mundo. Esta elección te otorga **20 puntos** extras directos al finalizar el torneo si tu equipo se consagra campeón." })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "glass p-5 rounded-3xl space-y-4", children: [
      /* @__PURE__ */ jsxs("h3", { className: "font-display text-2xl text-white flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Trophy, { className: "h-5 w-5 text-primary" }),
        " Estructura de Premios"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "p-3.5 rounded-xl bg-white/5 border border-white/10 relative overflow-hidden", children: [
          /* @__PURE__ */ jsx("div", { className: "absolute right-3 top-3 text-2xl", children: "🏆" }),
          /* @__PURE__ */ jsx("span", { className: "text-[10px] font-bold uppercase tracking-widest text-primary block", children: "Premio Mayor" }),
          /* @__PURE__ */ jsx("span", { className: "font-display text-xl text-white block mt-0.5", children: "Primer Lugar de la Clasificación" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-white/55 mt-1 leading-relaxed", children: "El pronosticador que finalice en el **puesto #1** del Ranking Global al concluir la final de la Copa del Mundo se coronará campeón de la quiniela y recibirá el **Premio Principal Grande**." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "p-3.5 rounded-xl bg-white/5 border border-white/10 relative overflow-hidden", children: [
          /* @__PURE__ */ jsx("div", { className: "absolute right-3 top-3 text-2xl", children: "🌍" }),
          /* @__PURE__ */ jsx("span", { className: "text-[10px] font-bold uppercase tracking-widest text-primary block", children: "Premio Especial" }),
          /* @__PURE__ */ jsx("span", { className: "font-display text-xl text-white block mt-0.5", children: "Acierto del Campeón Mundial" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-white/55 mt-1 leading-relaxed", children: "Todos los usuarios que acierten correctamente a la selección que se corona campeona del mundo (usando la predicción especial de Campeón) ganarán un **Premio Dedicado Secundario**." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "p-3.5 rounded-xl bg-white/5 border border-white/10 relative overflow-hidden", children: [
          /* @__PURE__ */ jsx("div", { className: "absolute right-3 top-3 text-2xl", children: "🏅" }),
          /* @__PURE__ */ jsx("span", { className: "text-[10px] font-bold uppercase tracking-widest text-primary block", children: "Premios Mensuales y Sorteos" }),
          /* @__PURE__ */ jsx("span", { className: "font-display text-xl text-white block mt-0.5", children: "Aciertos por Partido" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-white/55 mt-1 leading-relaxed", children: "Cada acierto (sin importar si es exacto o de ganador) te otorga puntos. Se realizarán sorteos periódicos de artículos oficiales del mundial entre todos los usuarios que acumulen puntos." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "glass p-5 rounded-3xl space-y-4", children: [
      /* @__PURE__ */ jsxs("h3", { className: "font-display text-2xl text-white flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Zap, { className: "h-5 w-5 text-primary" }),
        " Logros Especiales"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-white/60 leading-relaxed", children: "Además de la tabla de posiciones general, puedes desbloquear logros especiales que otorgan premios por separado." }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3.5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsx("div", { className: "text-3xl shrink-0 mt-0.5", children: "⚽" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-white block text-sm", children: "Primer Gol (Premio por Participación)" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-0.5 leading-relaxed", children: "Otorgado al registrar y guardar tu **primer pronóstico** en la aplicación. Te acredita la medalla en tu perfil y te ingresa a la lista de participantes oficiales." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsx("div", { className: "text-3xl shrink-0 mt-0.5", children: "🎯" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold text-white block text-sm", children: "Hat-Trick (Premio a la Racha Activa)" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-0.5 leading-relaxed", children: "Otorgado al acertar **3 marcadores exactos de forma consecutiva**. Demuestra tu nivel experto y te hace acreedor de un premio especial de alta precisión." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "p-3.5 rounded-xl bg-primary/5 border border-primary/20", children: [
          /* @__PURE__ */ jsx("span", { className: "text-[10px] font-bold uppercase tracking-widest text-primary block", children: "Pregunta Frecuente" }),
          /* @__PURE__ */ jsx("span", { className: "font-semibold text-white block text-sm mt-0.5", children: "¿Cómo se eligen estos logros?" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-white/60 mt-1 leading-relaxed", children: "**Estos logros no se seleccionan manualmente en una pantalla**. Son logros **dinámicos** y se calculan y otorgan automáticamente. El sistema audita tus predicciones en tiempo real y, en el momento que realizas tu primer pronóstico o encadenas 3 marcadores exactos seguidos, el logro se activa y se asigna a tu cuenta." })
        ] })
      ] })
    ] })
  ] });
}
function TermsContent() {
  return /* @__PURE__ */ jsx("div", { className: "space-y-4 text-xs text-white/70 leading-relaxed", children: /* @__PURE__ */ jsxs("div", { className: "glass p-5 rounded-3xl space-y-4", children: [
    /* @__PURE__ */ jsx("h3", { className: "font-display text-2xl text-white", children: "Términos de Servicio" }),
    /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-white/40 font-semibold", children: "Última actualización: Junio 2026" }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsx("p", { children: "Al registrarte e iniciar sesión en Golazo, aceptas los presentes términos y condiciones de juego. Te recomendamos leerlos detalladamente para asegurar una competencia limpia." }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "1. Elegibilidad para Participar" }),
      /* @__PURE__ */ jsx("p", { children: "La quiniela está abierta a todos los entusiastas del fútbol. Para reclamar premios físicos o monetarios en caso de resultar ganador, el participante debe cumplir con la legislación local de su país de residencia." }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "2. Reglas del Ranking y Desempate" }),
      /* @__PURE__ */ jsx("p", { children: "La clasificación se ordena de manera descendente en base a los puntos totales de cada perfil. En caso de empate en puntos entre dos o más usuarios, el sistema aplicará los siguientes criterios de desempate en orden de prioridad:" }),
      /* @__PURE__ */ jsxs("ul", { className: "list-disc pl-4 space-y-1 mt-1 text-white/60", children: [
        /* @__PURE__ */ jsxs("li", { children: [
          "Mayor cantidad de ",
          /* @__PURE__ */ jsx("strong", { children: "Marcadores Exactos" }),
          " acertados (3 puntos)."
        ] }),
        /* @__PURE__ */ jsxs("li", { children: [
          "Mayor porcentaje de ",
          /* @__PURE__ */ jsx("strong", { children: "Precisión" }),
          " global de predicciones."
        ] }),
        /* @__PURE__ */ jsx("li", { children: "Fecha y hora de registro de la cuenta (el usuario registrado más antiguo tiene la ventaja)." })
      ] }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "3. Tiempos Límite de Predicción" }),
      /* @__PURE__ */ jsx("p", { children: "Por motivos de juego justo, las predicciones de cada partido se cierran de manera estricta en el segundo que se marca el inicio oficial del partido (pitazo inicial). Una vez transcurrido este tiempo límite, el selector de predicción se bloqueará y no se admitirán registros ni modificaciones bajo ninguna circunstancia." }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "4. Juego Limpio y Prohibición de Abuso" }),
      /* @__PURE__ */ jsx("p", { children: "Queda estrictamente prohibido el uso de herramientas de automatización, bots o la creación de múltiples cuentas por un mismo individuo para obtener ventajas estadísticas. Cualquier cuenta sospechosa de realizar conductas fraudulentas será dada de baja y excluida permanentemente de las tablas de clasificación de la quiniela sin derecho a reclamos." }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "5. Modificación de Premios" }),
      /* @__PURE__ */ jsx("p", { children: "Los organizadores se reservan el derecho de modificar los premios ofrecidos por equivalentes de igual o mayor valor en caso de indisponibilidad logística, informando de ello oportunamente a la comunidad de usuarios." })
    ] })
  ] }) });
}
function PrivacyContent() {
  return /* @__PURE__ */ jsx("div", { className: "space-y-4 text-xs text-white/70 leading-relaxed", children: /* @__PURE__ */ jsxs("div", { className: "glass p-5 rounded-3xl space-y-4", children: [
    /* @__PURE__ */ jsx("h3", { className: "font-display text-2xl text-white", children: "Política de Privacidad" }),
    /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-white/40 font-semibold", children: "Última actualización: Junio 2026" }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsx("p", { children: "En Golazo nos tomamos muy en serio la seguridad y confidencialidad de tu información personal. Esta política explica cómo recopilamos, protegemos y utilizamos tus datos." }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "1. Datos Recopilados" }),
      /* @__PURE__ */ jsx("p", { children: "Al registrarte en Golazo, recopilamos únicamente los datos esenciales para la operación de la quiniela:" }),
      /* @__PURE__ */ jsxs("ul", { className: "list-disc pl-4 space-y-1 mt-1 text-white/60", children: [
        /* @__PURE__ */ jsxs("li", { children: [
          /* @__PURE__ */ jsx("strong", { children: "Dirección de correo electrónico:" }),
          " Necesaria para el inicio de sesión único, validación de cuenta y el restablecimiento de contraseñas olvidadas."
        ] }),
        /* @__PURE__ */ jsxs("li", { children: [
          /* @__PURE__ */ jsx("strong", { children: "Nombre de usuario y nombre completo:" }),
          " Utilizados exclusivamente para identificarte en el Ranking Global y podio del juego."
        ] }),
        /* @__PURE__ */ jsxs("li", { children: [
          /* @__PURE__ */ jsx("strong", { children: "Selección Favorita:" }),
          " Sirve para personalizar tu avatar y tu bandera nacional en la tabla de clasificación."
        ] })
      ] }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "2. Protección y Seguridad de la Información" }),
      /* @__PURE__ */ jsxs("p", { children: [
        "Golazo no gestiona contraseñas en texto plano ni almacena información en servidores desprotegidos. Toda la autenticación se realiza mediante el SDK cifrado de ",
        /* @__PURE__ */ jsx("strong", { children: "Supabase Auth" }),
        ". El acceso a los datos de predicciones está controlado por directivas de seguridad a nivel de fila (RLS - Row Level Security), garantizando que solo tú puedas editar o guardar tus predicciones."
      ] }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "3. Compartir Información" }),
      /* @__PURE__ */ jsx("p", { children: "Tus datos de contacto (como tu correo electrónico) jamás serán vendidos, alquilados o compartidos con terceros con fines comerciales o de spam. Solo utilizaremos tu correo electrónico para contactarte y coordinar la entrega física de tus premios si resultas ganador de alguno de los sorteos o del ranking general." }),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-white text-sm mt-4", children: "4. Derechos del Usuario" }),
      /* @__PURE__ */ jsx("p", { children: "Puedes actualizar tus datos de perfil en cualquier momento desde la sección de seguridad de tu cuenta. Si deseas dar de baja tu perfil y borrar tus predicciones permanentemente de nuestra base de datos, puedes solicitarlo escribiendo a nuestro canal de soporte técnico." })
    ] })
  ] }) });
}
export {
  RulesPage as component
};
