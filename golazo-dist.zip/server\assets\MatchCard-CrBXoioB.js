import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Clock, MapPin, Lock, Minus, Plus } from "lucide-react";
import { p as predictionsStore, d as calculateMatchPoints, i as isPredictionExact, F as Flag, s as supabase } from "./AppShell-B0dxobAF.js";
import { a as useTimeFormat, f as formatDay, b as formatTime } from "./router-Do2s6XFq.js";
import { toast } from "sonner";
function MatchCard({ match, compact = false }) {
  const { format } = useTimeFormat();
  const existing = predictionsStore.get(match.id);
  const [home, setHome] = useState(existing?.home ?? 1);
  const [away, setAway] = useState(existing?.away ?? 1);
  const [saved, setSaved] = useState(!!existing);
  const locked = match.status !== "scheduled";
  useEffect(() => {
    return predictionsStore.subscribe(() => {
      const p = predictionsStore.get(match.id);
      if (p) {
        setHome(p.home);
        setAway(p.away);
      }
    });
  }, [match.id]);
  const bump = (setter, val, delta) => {
    const next = Math.max(0, Math.min(9, val + delta));
    setter(next);
    setSaved(false);
  };
  const save = async () => {
    predictionsStore.set(match.id, { home, away });
    setSaved(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const { error } = await supabase.from("predictions").upsert(
          {
            user_id: session.user.id,
            match_id: match.id,
            home_score: home,
            away_score: away,
            updated_at: (/* @__PURE__ */ new Date()).toISOString()
          },
          { onConflict: "user_id,match_id" }
        );
        if (error) throw error;
        toast.success("¡Pronóstico guardado en la base de datos!");
      } else {
        toast.info(
          "Guardado en tu navegador. ¡Inicia sesión en tu Perfil para entrar al ranking global!"
        );
      }
    } catch (err) {
      console.error("Error al guardar pronóstico en Supabase:", err);
      toast.error("Error al sincronizar con la base de datos");
    }
  };
  const isKnockout = match.stage !== "group";
  const stageLabel = match.group ? `Grupo ${match.group}` : match.round;
  const points = isKnockout ? "5 / 3 pts" : "3 / 1 pts";
  const hasRealScore = match.status === "finished" || match.status === "live";
  return /* @__PURE__ */ jsxs("div", { className: `glass animate-float-up relative overflow-hidden rounded-3xl ${compact ? "p-4" : "p-5"}`, children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-center justify-between text-[11px] font-semibold uppercase tracking-[0.18em] text-white/60", children: [
      /* @__PURE__ */ jsx("span", { className: `rounded-full px-2.5 py-1 ${isKnockout ? "bg-primary/15 text-primary ring-1 ring-primary/30" : "bg-white/8"}`, children: stageLabel }),
      /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsx(Clock, { className: "h-3 w-3" }),
        " ",
        formatDay(match.kickoff),
        " · ",
        formatTime(match.kickoff, format)
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3", children: [
      /* @__PURE__ */ jsx(TeamSide, { team: match.home, align: "left" }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-col items-center", children: hasRealScore && match.scoreHome !== void 0 && match.scoreAway !== void 0 ? /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center", children: [
        /* @__PURE__ */ jsxs("span", { className: "font-display text-3xl font-extrabold text-gradient-neon leading-none", children: [
          match.scoreHome,
          " - ",
          match.scoreAway
        ] }),
        /* @__PURE__ */ jsx("span", { className: `mt-1.5 rounded-full px-2 py-0.5 text-[8px] font-bold uppercase tracking-widest ${match.status === "live" ? "bg-red-500/20 text-red-400 animate-pulse ring-1 ring-red-500/30" : "bg-white/10 text-white/60"}`, children: match.status === "live" ? "En Vivo" : "Final" })
      ] }) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center", children: [
        /* @__PURE__ */ jsx("span", { className: "font-display text-3xl font-extrabold text-white/20 leading-none", children: "0 - 0" }),
        /* @__PURE__ */ jsx("span", { className: "mt-1.5 rounded-full bg-white/5 px-2 py-0.5 text-[8px] font-bold uppercase tracking-widest text-white/40", children: "VS" })
      ] }) }),
      /* @__PURE__ */ jsx(TeamSide, { team: match.away, align: "right" })
    ] }),
    hasRealScore ? /* @__PURE__ */ jsxs("div", { className: "mt-5 flex items-center justify-between gap-3 rounded-2xl bg-white/5 p-3.5 ring-1 ring-white/10", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-xs", children: [
        /* @__PURE__ */ jsx("span", { className: "text-white/50", children: "Tu pronóstico: " }),
        existing ? /* @__PURE__ */ jsxs("span", { className: "font-display text-sm font-bold text-white ml-1", children: [
          existing.home,
          " - ",
          existing.away
        ] }) : /* @__PURE__ */ jsx("span", { className: "italic text-white/35 ml-1", children: "Sin pronóstico" })
      ] }),
      match.status === "finished" ? /* @__PURE__ */ jsx("div", { children: existing ? (() => {
        const pts = calculateMatchPoints(match, existing);
        const exact = isPredictionExact(match, existing);
        return /* @__PURE__ */ jsx("span", { className: `rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${pts > 0 ? "bg-green-500/15 text-green-400 ring-1 ring-green-500/30 neon-glow" : "bg-white/5 text-white/35"}`, children: pts > 0 ? `+${pts} PTS (${exact ? "Exacto" : "Acierto"})` : "0 PTS (Fallo)" });
      })() : /* @__PURE__ */ jsx("span", { className: "rounded-full bg-white/5 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white/35", children: "0 PTS" }) }) : /* @__PURE__ */ jsx("span", { className: "rounded-full bg-primary/15 text-primary px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ring-1 ring-primary/30 animate-pulse", children: "En juego" })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "mt-5 grid grid-cols-[1fr_auto_1fr] items-center gap-2", children: [
      /* @__PURE__ */ jsx(ScoreSelector, { value: home, onChange: (d) => bump(setHome, home, d), disabled: locked }),
      /* @__PURE__ */ jsx("div", { className: "font-display text-2xl text-white/30", children: ":" }),
      /* @__PURE__ */ jsx(ScoreSelector, { value: away, onChange: (d) => bump(setAway, away, d), disabled: locked })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-5 flex items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex min-w-0 flex-col gap-0.5 text-xs text-white/55", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsx(MapPin, { className: "h-3.5 w-3.5 shrink-0" }),
          /* @__PURE__ */ jsxs("span", { className: "truncate", children: [
            match.stadium,
            ", ",
            match.city
          ] })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "text-[10px] uppercase tracking-widest text-white/35", children: points })
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: save,
          disabled: locked,
          className: `group relative flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold uppercase tracking-wider transition active:scale-95
            ${locked ? "bg-white/5 text-white/40" : saved ? "bg-primary text-primary-foreground neon-glow" : "bg-white text-black hover:bg-primary"}`,
          children: locked ? /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(Lock, { className: "h-3.5 w-3.5" }),
            " Cerrado"
          ] }) : saved ? "Guardado ✓" : "Predecir"
        }
      )
    ] })
  ] });
}
function TeamSide({ team, align }) {
  const isTbd = team.code === "tbd";
  return /* @__PURE__ */ jsxs("div", { className: `flex items-center gap-3 ${align === "right" ? "flex-row-reverse text-right" : ""}`, children: [
    /* @__PURE__ */ jsx(Flag, { code: team.code, size: 56 }),
    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsx("div", { className: `font-display text-2xl leading-none ${isTbd ? "text-white/40" : "text-white"}`, children: isTbd ? "TBD" : team.short }),
      /* @__PURE__ */ jsx("div", { className: "mt-1 truncate text-[11px] text-white/50", children: team.name })
    ] })
  ] });
}
function ScoreSelector({ value, onChange, disabled }) {
  return /* @__PURE__ */ jsxs("div", { className: `glass flex items-center justify-between rounded-2xl p-2 ${disabled ? "opacity-50" : ""}`, children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => onChange(-1),
        disabled,
        className: "grid h-9 w-9 place-items-center rounded-xl bg-white/5 text-white/70 transition hover:bg-white/10 active:scale-90 disabled:opacity-30",
        children: /* @__PURE__ */ jsx(Minus, { className: "h-4 w-4" })
      }
    ),
    /* @__PURE__ */ jsx("span", { className: "font-display w-10 text-center text-4xl text-gradient-neon", children: value }),
    /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => onChange(1),
        disabled,
        className: "grid h-9 w-9 place-items-center rounded-xl bg-primary/20 text-primary transition hover:bg-primary/30 active:scale-90 disabled:opacity-30",
        children: /* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" })
      }
    )
  ] });
}
export {
  MatchCard as M
};
