import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { Menu, Mail, Lock, EyeOff, Eye, User, Flag, LogOut, Share2, Trophy, ChevronRight, BookOpen, ShieldCheck } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { u as useAuth, m as matches, a as groups, p as predictionsStore, c as calculateUserStats, b as getDynamicLeaderboard, A as AppShell, t as teams, F as Flag$1, s as supabase } from "./AppShell-B0dxobAF.js";
import { f as fetchRealGroupsAndMatches } from "./api-football-DNOoAqkn.js";
import { toast } from "sonner";
import { u as useSidebar } from "./router-Do2s6XFq.js";
import "@supabase/supabase-js";
import "zod";
function ProfilePage() {
  const {
    user,
    profile,
    loading
  } = useAuth();
  const {
    open: openSidebar
  } = useSidebar();
  const [tab, setTab] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [username, setUsername] = useState("");
  const [fullName, setFullName] = useState("");
  const [countryCode, setCountryCode] = useState("cr");
  const [submitting, setSubmitting] = useState(false);
  const [submittingPassword, setSubmittingPassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const {
    data: apiData
  } = useQuery({
    queryKey: ["realMatchesAndGroups"],
    queryFn: fetchRealGroupsAndMatches,
    retry: 2,
    retryDelay: 2e3,
    staleTime: 0,
    gcTime: 0
  });
  const matchesList = apiData?.matches || matches;
  apiData?.groups || groups;
  predictionsStore.getAll();
  const dynamicStats = calculateUserStats(matchesList);
  const leaderboardList = getDynamicLeaderboard(matchesList);
  const userRank = user ? leaderboardList.find((p) => p.id === user.id)?.rank || 1 : 1;
  const s = {
    predictions: user ? dynamicStats.predictions : 0,
    correct: user ? dynamicStats.correct : 0,
    exact: user ? dynamicStats.exact : 0,
    accuracy: user ? dynamicStats.accuracy : 0,
    points: user ? dynamicStats.points : 0,
    rank: user ? userRank : "--"
  };
  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Por favor completa todos los campos");
      return;
    }
    setSubmitting(true);
    try {
      const {
        error
      } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      if (error) throw error;
      toast.success("¡Sesión iniciada con éxito!");
    } catch (err) {
      toast.error("Error al iniciar sesión: " + (err.message || err));
    } finally {
      setSubmitting(false);
    }
  };
  const handleRegister = async (e) => {
    e.preventDefault();
    if (!email || !password || !username || !fullName) {
      toast.error("Por favor completa todos los campos");
      return;
    }
    if (password.length < 6) {
      toast.error("La contraseña debe tener al menos 6 caracteres");
      return;
    }
    setSubmitting(true);
    try {
      const {
        error
      } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username: username.toLowerCase().trim(),
            full_name: fullName.trim(),
            country_code: countryCode
          }
        }
      });
      if (error) throw error;
      toast.success("¡Cuenta creada! Ya puedes iniciar sesión con tus credenciales.");
      setTab("login");
    } catch (err) {
      toast.error("Error al registrarse: " + (err.message || err));
    } finally {
      setSubmitting(false);
    }
  };
  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast.info("Sesión cerrada");
    } catch (err) {
      console.error(err);
    }
  };
  const handleForgotPassword = async (e) => {
    e.preventDefault();
    if (!email) {
      toast.error("Por favor ingresa tu correo electrónico");
      return;
    }
    setSubmitting(true);
    try {
      const {
        error
      } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + "/profile"
      });
      if (error) throw error;
      toast.success("¡Correo de recuperación enviado! Revisa tu bandeja de entrada.");
      setTab("login");
    } catch (err) {
      toast.error("Error al enviar el correo: " + (err.message || err));
    } finally {
      setSubmitting(false);
    }
  };
  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      toast.error("La contraseña debe tener al menos 6 caracteres");
      return;
    }
    setSubmittingPassword(true);
    try {
      const {
        error
      } = await supabase.auth.updateUser({
        password: newPassword
      });
      if (error) throw error;
      toast.success("¡Contraseña actualizada con éxito!");
      setNewPassword("");
    } catch (err) {
      toast.error("Error al actualizar la contraseña: " + (err.message || err));
    } finally {
      setSubmittingPassword(false);
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsx(AppShell, { children: /* @__PURE__ */ jsxs("div", { className: "flex h-[60vh] flex-col items-center justify-center gap-4", children: [
      /* @__PURE__ */ jsx("div", { className: "h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" }),
      /* @__PURE__ */ jsx("span", { className: "text-sm text-white/55", children: "Cargando perfil..." })
    ] }) });
  }
  if (!user) {
    return /* @__PURE__ */ jsxs(AppShell, { children: [
      /* @__PURE__ */ jsxs("header", { className: "px-5 pt-[max(28px,env(safe-area-inset-top))] text-center relative", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute left-5 top-[max(28px,env(safe-area-inset-top))]", children: /* @__PURE__ */ jsx("button", { onClick: openSidebar, title: "Menú", className: "glass grid h-9 w-9 place-items-center rounded-full hover:bg-white/15 transition", children: /* @__PURE__ */ jsx(Menu, { className: "h-4 w-4 text-white" }) }) }),
        /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold uppercase tracking-[0.25em] text-primary block mt-1", children: "Únete a Golazo" }),
        /* @__PURE__ */ jsx("h1", { className: "font-display mt-1 text-5xl leading-none text-white", children: "Tu Quiniela" }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-white/55", children: "Inicia sesión o crea tu cuenta para guardar predicciones y competir." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 px-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex rounded-2xl bg-white/5 p-1 ring-1 ring-white/10 mb-6", children: [
          /* @__PURE__ */ jsx("button", { onClick: () => setTab("login"), className: `flex-1 rounded-xl py-2.5 text-xs font-bold uppercase tracking-wider transition ${tab === "login" ? "bg-white text-black font-extrabold" : "text-white/60 hover:text-white"}`, children: "Iniciar Sesión" }),
          /* @__PURE__ */ jsx("button", { onClick: () => setTab("register"), className: `flex-1 rounded-xl py-2.5 text-xs font-bold uppercase tracking-wider transition ${tab === "register" ? "bg-white text-black font-extrabold" : "text-white/60 hover:text-white"}`, children: "Registrarse" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "glass p-6 rounded-3xl relative overflow-hidden", children: [
          /* @__PURE__ */ jsx("div", { className: "absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-transparent to-transparent" }),
          tab === "forgot" ? /* @__PURE__ */ jsxs("form", { onSubmit: handleForgotPassword, className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "text-center mb-2", children: [
              /* @__PURE__ */ jsx("h3", { className: "font-display text-lg text-white", children: "Recuperar Contraseña" }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-white/55 mt-1", children: "Te enviaremos un correo para que puedas restablecerla." })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Correo Electrónico" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(Mail, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "tu@correo.com", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-4 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true })
              ] })
            ] }),
            /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting, className: "w-full rounded-2xl bg-primary py-3.5 text-xs font-bold uppercase tracking-widest text-primary-foreground transition active:scale-95 disabled:opacity-50 neon-glow mt-4", children: submitting ? "Enviando..." : "Enviar Correo" }),
            /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setTab("login"), className: "w-full text-center text-xs text-white/50 hover:text-white transition mt-2 block", children: "Volver al Inicio de Sesión" })
          ] }) : tab === "login" ? /* @__PURE__ */ jsxs("form", { onSubmit: handleLogin, className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Correo Electrónico" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(Mail, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "tu@correo.com", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-4 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center", children: [
                /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Contraseña" }),
                /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setTab("forgot"), className: "text-[10px] uppercase tracking-widest text-primary font-semibold hover:underline", children: "¿La olvidaste?" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(Lock, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("input", { type: showPassword ? "text" : "password", value: password, onChange: (e) => setPassword(e.target.value), placeholder: "••••••", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-12 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true }),
                /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setShowPassword(!showPassword), className: "absolute right-4 top-3.5 z-10 text-white/70 hover:text-primary transition", children: showPassword ? /* @__PURE__ */ jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" }) })
              ] })
            ] }),
            /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting, className: "w-full rounded-2xl bg-primary py-3.5 text-xs font-bold uppercase tracking-widest text-primary-foreground transition active:scale-95 disabled:opacity-50 neon-glow mt-4", children: submitting ? "Cargando..." : "Ingresar" })
          ] }) : /* @__PURE__ */ jsxs("form", { onSubmit: handleRegister, className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Apodo / Nombre de Usuario" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(User, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("input", { type: "text", value: username, onChange: (e) => setUsername(e.target.value), placeholder: "ej. golazo_campeon", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-4 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Nombre Completo" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(User, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("input", { type: "text", value: fullName, onChange: (e) => setFullName(e.target.value), placeholder: "ej. Alejandro Gómez", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-4 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Selección Favorita" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(Flag, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("select", { value: countryCode, onChange: (e) => setCountryCode(e.target.value), className: "w-full rounded-2xl bg-[#11171d] py-3 pl-11 pr-4 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition appearance-none", children: teams.sort((a, b) => a.name.localeCompare(b.name)).map((team) => /* @__PURE__ */ jsx("option", { value: team.code, className: "bg-background", children: team.name }, team.code)) })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Correo Electrónico" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(Mail, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "tu@correo.com", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-4 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Contraseña" }),
              /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsx(Lock, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
                /* @__PURE__ */ jsx("input", { type: showPassword ? "text" : "password", value: password, onChange: (e) => setPassword(e.target.value), placeholder: "Mínimo 6 caracteres", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-12 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true }),
                /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setShowPassword(!showPassword), className: "absolute right-4 top-3.5 z-10 text-white/70 hover:text-primary transition", children: showPassword ? /* @__PURE__ */ jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" }) })
              ] })
            ] }),
            /* @__PURE__ */ jsx("button", { type: "submit", disabled: submitting, className: "w-full rounded-2xl bg-primary py-3.5 text-xs font-bold uppercase tracking-widest text-primary-foreground transition active:scale-95 disabled:opacity-50 neon-glow mt-4", children: submitting ? "Creando cuenta..." : "Registrarse" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-8 mb-10 flex justify-center gap-6 text-xs text-white/40", children: [
          /* @__PURE__ */ jsx(Link, { to: "/rules", search: {
            tab: "manual"
          }, className: "hover:text-primary transition font-semibold", children: "Manual de Juego" }),
          /* @__PURE__ */ jsx("span", { children: "•" }),
          /* @__PURE__ */ jsx(Link, { to: "/rules", search: {
            tab: "terms"
          }, className: "hover:text-primary transition font-semibold", children: "Términos" }),
          /* @__PURE__ */ jsx("span", { children: "•" }),
          /* @__PURE__ */ jsx(Link, { to: "/rules", search: {
            tab: "privacy"
          }, className: "hover:text-primary transition font-semibold", children: "Privacidad" })
        ] })
      ] })
    ] });
  }
  const displayProfile = profile || {
    full_name: user.email?.split("@")[0] || "Usuario",
    username: user.email?.split("@")[0] || "usuario",
    country_code: "cr"
  };
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsxs("section", { className: "relative px-5 pt-[max(28px,env(safe-area-inset-top))]", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("button", { onClick: openSidebar, title: "Menú", className: "glass grid h-9 w-9 place-items-center rounded-full hover:bg-white/15 transition", children: /* @__PURE__ */ jsx(Menu, { className: "h-4 w-4 text-white" }) }),
          /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold uppercase tracking-[0.25em] text-primary", children: "Mi Identidad" })
        ] }),
        /* @__PURE__ */ jsx("button", { onClick: handleLogout, title: "Cerrar Sesión", className: "glass grid h-9 w-9 place-items-center rounded-full hover:bg-white/15 transition", children: /* @__PURE__ */ jsx(LogOut, { className: "h-4 w-4 text-white/70 hover:text-red-400" }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-6 flex flex-col items-center text-center", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(Flag$1, { code: displayProfile.country_code, size: 120, className: "ring-4 ring-primary/40 neon-glow" }),
          /* @__PURE__ */ jsxs("span", { className: "absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-0.5 text-[10px] font-bold uppercase tracking-widest text-primary-foreground animate-float", children: [
            "#",
            s.rank
          ] })
        ] }),
        /* @__PURE__ */ jsx("h1", { className: "font-display mt-5 text-4xl leading-none text-white", children: displayProfile.full_name }),
        /* @__PURE__ */ jsxs("p", { className: "mt-1 text-sm text-white/55", children: [
          "@",
          displayProfile.username,
          " · Cuenta Sincronizada"
        ] }),
        /* @__PURE__ */ jsxs("button", { className: "mt-4 inline-flex items-center gap-2 rounded-full bg-white px-5 py-2 text-xs font-bold uppercase tracking-widest text-black active:scale-95", children: [
          /* @__PURE__ */ jsx(Share2, { className: "h-3.5 w-3.5" }),
          " Compartir Perfil"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "mt-8 px-4", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-3", children: [
      /* @__PURE__ */ jsx(Stat, { label: "Puntos", value: s.points, accent: "neon" }),
      /* @__PURE__ */ jsx(Stat, { label: "Predicciones", value: s.predictions }),
      /* @__PURE__ */ jsx(Stat, { label: "Aciertos", value: s.correct }),
      /* @__PURE__ */ jsx(Stat, { label: "Marcadores Exactos", value: s.exact, accent: "gold" }),
      /* @__PURE__ */ jsx(Stat, { label: "Precisión", value: `${s.accuracy}%`, accent: "neon" }),
      /* @__PURE__ */ jsx(Stat, { label: "Posición", value: `#${s.rank}`, accent: "gold" })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "mt-6 px-4", children: /* @__PURE__ */ jsxs("div", { className: "glass rounded-3xl p-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-end justify-between", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-[11px] uppercase tracking-widest text-white/50", children: "Precisión de Predicciones" }),
          /* @__PURE__ */ jsxs("div", { className: "font-display text-4xl text-gradient-neon", children: [
            s.accuracy,
            "%"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-xs text-white/55", children: [
          s.correct,
          " de ",
          s.predictions,
          " aciertos"
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-4 h-2 overflow-hidden rounded-full bg-white/8", children: /* @__PURE__ */ jsx("div", { className: "h-full rounded-full bg-gradient-to-r from-primary to-[oklch(0.7_0.2_180)]", style: {
        width: `${s.accuracy}%`
      } }) })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "mt-8 px-4", children: /* @__PURE__ */ jsxs(Link, { to: "/my-predictions", className: "glass-strong relative flex items-center gap-4 overflow-hidden rounded-3xl p-5 transition active:scale-[0.99] hover:bg-white/5", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_100%_50%,oklch(0.86_0.22_152/0.18),transparent_60%)]" }),
      /* @__PURE__ */ jsx("div", { className: "relative grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-primary to-[oklch(0.7_0.2_180)]", children: /* @__PURE__ */ jsx(Trophy, { className: "h-6 w-6 text-black", strokeWidth: 2 }) }),
      /* @__PURE__ */ jsxs("div", { className: "relative flex-1", children: [
        /* @__PURE__ */ jsx("div", { className: "text-[10px] font-bold uppercase tracking-widest text-primary", children: "Historial y Comparador" }),
        /* @__PURE__ */ jsx("div", { className: "font-display text-xl text-white mt-0.5", children: "Mis Pronósticos Guardados" }),
        /* @__PURE__ */ jsx("div", { className: "text-xs text-white/55 mt-0.5", children: "Revisa tus predicciones y compáralas frente a los marcadores reales." })
      ] }),
      /* @__PURE__ */ jsx(ChevronRight, { className: "relative h-5 w-5 text-white/50" })
    ] }) }),
    /* @__PURE__ */ jsxs("section", { className: "mt-6 px-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "mb-3 px-1 font-display text-2xl text-white", children: "Logros" }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "glass relative overflow-hidden rounded-2xl p-4", children: [
          /* @__PURE__ */ jsx("div", { className: "text-3xl", children: "⚽" }),
          /* @__PURE__ */ jsx("div", { className: "mt-2 font-display text-lg text-white", children: "Primer Gol" }),
          /* @__PURE__ */ jsx("div", { className: "text-[11px] text-white/55", children: "Hiciste tu primera predicción" }),
          /* @__PURE__ */ jsx("div", { className: "absolute -right-4 -top-4 h-16 w-16 rounded-full bg-primary/15 blur-2xl" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "glass relative overflow-hidden rounded-2xl p-4 opacity-50", children: [
          /* @__PURE__ */ jsx("div", { className: "text-3xl", children: "🎯" }),
          /* @__PURE__ */ jsx("div", { className: "mt-2 font-display text-lg text-white", children: "Hat-Trick" }),
          /* @__PURE__ */ jsx("div", { className: "text-[11px] text-white/55", children: "3 marcadores exactos seguidos" }),
          /* @__PURE__ */ jsx("div", { className: "absolute -right-4 -top-4 h-16 w-16 rounded-full bg-primary/15 blur-2xl" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "mt-8 px-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "mb-3 px-1 font-display text-2xl text-white", children: "Ayuda e Información" }),
      /* @__PURE__ */ jsxs("div", { className: "glass rounded-3xl p-2 space-y-1", children: [
        /* @__PURE__ */ jsxs(Link, { to: "/rules", search: {
          tab: "manual"
        }, className: "flex items-center justify-between p-3.5 hover:bg-white/5 rounded-2xl transition", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx(BookOpen, { className: "h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold text-white", children: "Manual y Premios de Juego" })
          ] }),
          /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4 text-white/30" })
        ] }),
        /* @__PURE__ */ jsxs(Link, { to: "/rules", search: {
          tab: "terms"
        }, className: "flex items-center justify-between p-3.5 hover:bg-white/5 rounded-2xl transition border-t border-white/5", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx(User, { className: "h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold text-white", children: "Términos y Condiciones" })
          ] }),
          /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4 text-white/30" })
        ] }),
        /* @__PURE__ */ jsxs(Link, { to: "/rules", search: {
          tab: "privacy"
        }, className: "flex items-center justify-between p-3.5 hover:bg-white/5 rounded-2xl transition border-t border-white/5", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx(ShieldCheck, { className: "h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsx("div", { className: "text-sm font-semibold text-white", children: "Política de Privacidad" })
          ] }),
          /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4 text-white/30" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "mt-8 px-4 mb-10", children: /* @__PURE__ */ jsxs("div", { className: "glass rounded-3xl p-5 relative overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-transparent to-transparent" }),
      /* @__PURE__ */ jsx("h3", { className: "font-display text-2xl text-white mb-1", children: "Seguridad" }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mb-4", children: "Actualiza tu contraseña para mantener tu cuenta segura." }),
      /* @__PURE__ */ jsxs("form", { onSubmit: handleChangePassword, className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx("label", { className: "text-[10px] uppercase tracking-widest text-white/50 block font-semibold", children: "Nueva Contraseña" }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx(Lock, { className: "absolute left-4 top-3.5 h-4 w-4 text-white/40" }),
            /* @__PURE__ */ jsx("input", { type: showNewPassword ? "text" : "password", value: newPassword, onChange: (e) => setNewPassword(e.target.value), placeholder: "Mínimo 6 caracteres", className: "w-full rounded-2xl bg-white/5 py-3 pl-11 pr-12 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-2 focus:ring-primary transition", required: true }),
            /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setShowNewPassword(!showNewPassword), className: "absolute right-4 top-3.5 z-10 text-white/70 hover:text-primary transition", children: showNewPassword ? /* @__PURE__ */ jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsx("button", { type: "submit", disabled: submittingPassword, className: "w-full rounded-2xl bg-primary py-3.5 text-xs font-bold uppercase tracking-widest text-primary-foreground transition active:scale-95 disabled:opacity-50 neon-glow mt-2", children: submittingPassword ? "Actualizando..." : "Actualizar Contraseña" })
      ] })
    ] }) })
  ] });
}
function Stat({
  label,
  value,
  accent
}) {
  return /* @__PURE__ */ jsxs("div", { className: "glass rounded-2xl p-3 text-center", children: [
    /* @__PURE__ */ jsx("div", { className: `font-display text-2xl ${accent === "neon" ? "text-gradient-neon" : accent === "gold" ? "text-gradient-gold" : "text-white"}`, children: value }),
    /* @__PURE__ */ jsx("div", { className: "mt-1 text-[10px] uppercase tracking-widest text-white/50", children: label })
  ] });
}
export {
  ProfilePage as component
};
