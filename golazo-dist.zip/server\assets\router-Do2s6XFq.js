import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { createRootRouteWithContext, useRouter, Link, Outlet, HeadContent, Scripts, createFileRoute, lazyRouteComponent, createRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect, createContext, useContext } from "react";
import { Toaster } from "sonner";
import { z } from "zod";
const appCss = "/assets/styles-zYnMh6ep.css";
const TimeFormatContext = createContext(null);
const STORAGE_KEY = "golazo:timeFormat";
function TimeFormatProvider({ children }) {
  const [format, setFormatState] = useState("12h");
  useEffect(() => {
    try {
      const v = sessionStorage.getItem(STORAGE_KEY);
      if (v === "12h" || v === "24h") setFormatState(v);
    } catch {
    }
  }, []);
  const setFormat = (f) => {
    setFormatState(f);
    try {
      sessionStorage.setItem(STORAGE_KEY, f);
    } catch {
    }
  };
  const toggle = () => setFormat(format === "12h" ? "24h" : "12h");
  return /* @__PURE__ */ jsx(TimeFormatContext.Provider, { value: { format, toggle, setFormat }, children });
}
function useTimeFormat() {
  const ctx = useContext(TimeFormatContext);
  if (!ctx) return { format: "12h", toggle: () => {
  }, setFormat: () => {
  } };
  return ctx;
}
function formatTime(iso, format) {
  const d = new Date(iso);
  return d.toLocaleTimeString("es-ES", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: format === "12h"
  });
}
function formatDay(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString("es-ES", { weekday: "short", day: "2-digit", month: "short" });
}
function isSameDay(iso, ref = /* @__PURE__ */ new Date()) {
  const d = new Date(iso);
  return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth() && d.getDate() === ref.getDate();
}
function TimeFormatToggle({ className = "" }) {
  const { format, toggle } = useTimeFormat();
  return /* @__PURE__ */ jsxs(
    "button",
    {
      onClick: toggle,
      "aria-label": "Cambiar formato de hora",
      className: `glass relative flex h-8 w-[88px] items-center rounded-full p-1 text-[10px] font-bold uppercase tracking-widest transition active:scale-95 ${className}`,
      children: [
        /* @__PURE__ */ jsx(
          "span",
          {
            className: `absolute top-1 bottom-1 w-[40px] rounded-full bg-primary neon-glow transition-transform ${format === "24h" ? "translate-x-[40px]" : "translate-x-0"}`
          }
        ),
        /* @__PURE__ */ jsx("span", { className: `relative z-10 flex-1 text-center ${format === "12h" ? "text-primary-foreground" : "text-white/60"}`, children: "AM/PM" }),
        /* @__PURE__ */ jsx("span", { className: `relative z-10 flex-1 text-center ${format === "24h" ? "text-primary-foreground" : "text-white/60"}`, children: "24h" })
      ]
    }
  );
}
const SidebarContext = createContext(void 0);
function SidebarProvider({ children }) {
  const [isOpen, setIsOpen] = useState(false);
  const open = () => setIsOpen(true);
  const close = () => setIsOpen(false);
  const toggle = () => setIsOpen((prev) => !prev);
  return /* @__PURE__ */ jsx(SidebarContext.Provider, { value: { isOpen, open, close, toggle }, children });
}
function useSidebar() {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider");
  }
  return context;
}
function NotFoundComponent() {
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$7 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#0a0f14" },
      { title: "Golazo — World Cup Predictions" },
      { name: "description", content: "Predict every World Cup match. Climb the global leaderboard. Feel the cup." },
      { property: "og:title", content: "Golazo — World Cup Predictions" },
      { property: "og:description", content: "Premium World Cup prediction experience." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" }
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter+Tight:wght@400;500;600;700;800&display=swap"
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsx("head", { children: /* @__PURE__ */ jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$7.useRouteContext();
  return /* @__PURE__ */ jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsx(TimeFormatProvider, { children: /* @__PURE__ */ jsxs(SidebarProvider, { children: [
    /* @__PURE__ */ jsx(Outlet, {}),
    /* @__PURE__ */ jsx(Toaster, { position: "top-center", theme: "dark", closeButton: true, richColors: true })
  ] }) }) });
}
const $$splitComponentImporter$6 = () => import("./rules-D5th4BmK.js");
const rulesSearchSchema = z.object({
  tab: z.enum(["manual", "terms", "privacy"]).catch("manual")
});
const Route$6 = createFileRoute("/rules")({
  validateSearch: (search) => rulesSearchSchema.parse(search),
  head: () => ({
    meta: [{
      title: "Reglamento y Manual · Golazo"
    }, {
      name: "description",
      content: "Reglas de la quiniela, manual de puntuación, términos y políticas de Golazo."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./ranking-CW2ffMCx.js");
const Route$5 = createFileRoute("/ranking")({
  head: () => ({
    meta: [{
      title: "Ranking · Golazo"
    }, {
      name: "description",
      content: "Clasificación global de predicciones del Mundial."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./profile-Ck4I-UHf.js");
const Route$4 = createFileRoute("/profile")({
  head: () => ({
    meta: [{
      title: "Perfil · Golazo"
    }, {
      name: "description",
      content: "Tu identidad futbolera, estadísticas y logros de la quiniela."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./my-predictions-C5tMgeTU.js");
const Route$3 = createFileRoute("/my-predictions")({
  head: () => ({
    meta: [{
      title: "Mis Pronósticos · Golazo"
    }, {
      name: "description",
      content: "Historial completo de tus predicciones y comparación con los resultados reales."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./matches-D5GkN5wm.js");
const matchesSearchSchema = z.object({
  group: z.string().optional(),
  stage: z.string().optional()
});
const Route$2 = createFileRoute("/matches")({
  validateSearch: (search) => matchesSearchSchema.parse(search),
  head: () => ({
    meta: [{
      title: "Partidos · Golazo"
    }, {
      name: "description",
      content: "Todos los partidos del Mundial 2026, grupo por grupo y fase final."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./champion-CNq-6RRR.js");
const Route$1 = createFileRoute("/champion")({
  head: () => ({
    meta: [{
      title: "Campeón del Mundo · Golazo"
    }, {
      name: "description",
      content: "Elige al campeón del Mundial 2026. 20 puntos si aciertas."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./index-6D13CPJt.js");
const Route = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Golazo — Inicio"
    }, {
      name: "description",
      content: "Partidos próximos del Mundial 2026, tu ranking y tu próxima predicción."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const RulesRoute = Route$6.update({
  id: "/rules",
  path: "/rules",
  getParentRoute: () => Route$7
});
const RankingRoute = Route$5.update({
  id: "/ranking",
  path: "/ranking",
  getParentRoute: () => Route$7
});
const ProfileRoute = Route$4.update({
  id: "/profile",
  path: "/profile",
  getParentRoute: () => Route$7
});
const MyPredictionsRoute = Route$3.update({
  id: "/my-predictions",
  path: "/my-predictions",
  getParentRoute: () => Route$7
});
const MatchesRoute = Route$2.update({
  id: "/matches",
  path: "/matches",
  getParentRoute: () => Route$7
});
const ChampionRoute = Route$1.update({
  id: "/champion",
  path: "/champion",
  getParentRoute: () => Route$7
});
const IndexRoute = Route.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$7
});
const rootRouteChildren = {
  IndexRoute,
  ChampionRoute,
  MatchesRoute,
  MyPredictionsRoute,
  ProfileRoute,
  RankingRoute,
  RulesRoute
};
const routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route$6 as R,
  TimeFormatToggle as T,
  useTimeFormat as a,
  formatTime as b,
  Route$2 as c,
  formatDay as f,
  isSameDay as i,
  router as r,
  useSidebar as u
};
