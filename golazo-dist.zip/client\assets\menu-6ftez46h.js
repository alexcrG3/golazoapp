import{c as e}from"./AppShell-DMBDcJz1.js";const t=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],o=e("menu",t);export{o as M};
