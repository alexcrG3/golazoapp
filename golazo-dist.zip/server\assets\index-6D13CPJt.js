import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Menu, ChevronRight, Trophy, Zap, Calendar } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { f as teamByCode, l as leaderboard, u as useAuth, m as matches, c as calculateUserStats, g as getSupabaseLeaderboard, n as nextMatch, o as upcomingMatches, k as useChampion, A as AppShell, F as Flag } from "./AppShell-B0dxobAF.js";
import { M as MatchCard } from "./MatchCard-CrBXoioB.js";
import { u as useSidebar, a as useTimeFormat, i as isSameDay, T as TimeFormatToggle, f as formatDay, b as formatTime } from "./router-Do2s6XFq.js";
import { f as fetchRealGroupsAndMatches } from "./api-football-DNOoAqkn.js";
import "@supabase/supabase-js";
import "sonner";
import "zod";
const you = leaderboard.find((p) => p.isYou);
const userProfile = {
  name: you.name,
  country: teamByCode(you.country),
  stats: {
    accuracy: you.accuracy,
    rank: you.rank,
    points: you.points
  }
};
const stadiumHero = "/assets/stadium-hero-_Hb8O-ws.jpg";
function useCountdown(targetIso) {
  const target = new Date(targetIso).getTime();
  const [now, setNow] = useState(target);
  useEffect(() => {
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 1e3);
    return () => clearInterval(id);
  }, []);
  const diff = Math.max(0, target - now);
  const h = Math.floor(diff / 36e5);
  const m = Math.floor(diff % 36e5 / 6e4);
  const s = Math.floor(diff % 6e4 / 1e3);
  return {
    h,
    m,
    s
  };
}
function HomePage() {
  const {
    data: apiData
  } = useQuery({
    queryKey: ["realMatchesAndGroups"],
    queryFn: fetchRealGroupsAndMatches,
    retry: 2,
    retryDelay: 2e3,
    staleTime: 0,
    gcTime: 0
  });
  const {
    user,
    profile
  } = useAuth();
  const {
    open: openSidebar
  } = useSidebar();
  const matchesList = apiData?.matches || matches;
  const stats = calculateUserStats(matchesList);
  const {
    data: leaderboardList = []
  } = useQuery({
    queryKey: ["supabaseLeaderboard", matchesList, user?.id],
    queryFn: () => getSupabaseLeaderboard(matchesList, user?.id),
    enabled: matchesList.length > 0
  });
  const userRank = user ? leaderboardList.find((p) => p.isYou)?.rank || "--" : "--";
  const featured = nextMatch(matchesList);
  const upcoming = upcomingMatches(3, matchesList);
  const {
    format
  } = useTimeFormat();
  const championCode = useChampion();
  const champion = championCode ? teamByCode(championCode) : null;
  const [today, setToday] = useState([]);
  useEffect(() => {
    setToday(matchesList.filter((m2) => isSameDay(m2.kickoff)));
  }, [matchesList]);
  const {
    h,
    m,
    s
  } = useCountdown(featured.kickoff);
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsx("section", { className: "relative", children: /* @__PURE__ */ jsxs("div", { className: "relative h-[520px] overflow-hidden", children: [
      /* @__PURE__ */ jsx("img", { src: stadiumHero, alt: "Ambiente de estadio", width: 1080, height: 1920, className: "absolute inset-0 h-full w-full object-cover" }),
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-b from-black/40 via-background/30 to-background" }),
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,oklch(0.86_0.22_152/0.18),transparent_60%)]" }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 flex items-center justify-between px-5 pt-[max(20px,env(safe-area-inset-top))]", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx("button", { onClick: openSidebar, title: "Menú", className: "glass grid h-9 w-9 place-items-center rounded-full hover:bg-white/15 transition", children: /* @__PURE__ */ jsx(Menu, { className: "h-4 w-4 text-white" }) }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground neon-glow", children: /* @__PURE__ */ jsx("span", { className: "font-display text-lg", children: "G" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("div", { className: "font-display text-xl leading-none tracking-wide", children: "GOLAZO" }),
              /* @__PURE__ */ jsx("div", { className: "text-[10px] uppercase tracking-[0.25em] text-white/50", children: "Mundial 26" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "glass flex items-center gap-2 rounded-full px-3 py-1.5", children: [
            /* @__PURE__ */ jsx(Flag, { code: profile?.country_code || userProfile.country.code, size: 22 }),
            /* @__PURE__ */ jsxs("span", { className: "text-xs font-semibold", children: [
              "#",
              userRank
            ] })
          ] }),
          /* @__PURE__ */ jsx(Link, { to: "/profile", className: "shrink-0 transition active:scale-95", children: /* @__PURE__ */ jsx(Flag, { code: profile?.country_code || "cr", size: 32, className: "ring-2 ring-white/10" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 mt-10 px-5", children: [
        /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-primary ring-1 ring-primary/30", children: [
          /* @__PURE__ */ jsx("span", { className: "h-1.5 w-1.5 animate-pulse rounded-full bg-primary" }),
          " Torneo en Vivo"
        ] }),
        /* @__PURE__ */ jsxs("h1", { className: "font-display mt-3 text-5xl leading-[0.95] text-white", children: [
          "Predice el",
          /* @__PURE__ */ jsx("br", {}),
          /* @__PURE__ */ jsx("span", { className: "text-gradient-neon", children: "momento de gloria." })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-3 max-w-xs text-sm text-white/70", children: "Cada partido. Cada marcador. Cada emoción. Escala el ranking global." })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "-mt-40 relative z-10 px-4", children: /* @__PURE__ */ jsxs("div", { className: "glass-strong overflow-hidden rounded-3xl", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b border-white/10 px-5 py-3", children: [
        /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold uppercase tracking-[0.2em] text-primary", children: "Próximo Pitazo" }),
        /* @__PURE__ */ jsx("span", { className: "text-[11px] uppercase tracking-wider text-white/50", children: featured.group ? `Grupo ${featured.group}` : featured.round })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "px-5 py-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-around", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-2", children: [
            /* @__PURE__ */ jsx(Flag, { code: featured.home.code, size: 72 }),
            /* @__PURE__ */ jsx("span", { className: "font-display text-lg text-white", children: featured.home.short })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center", children: [
            /* @__PURE__ */ jsx("div", { className: "font-display text-xs tracking-[0.3em] text-white/40", children: "COMIENZA EN" }),
            /* @__PURE__ */ jsxs("div", { className: "mt-2 flex items-end gap-1", suppressHydrationWarning: true, children: [
              /* @__PURE__ */ jsx(Tile, { v: String(h).padStart(2, "0") }),
              /* @__PURE__ */ jsx(Sep, {}),
              /* @__PURE__ */ jsx(Tile, { v: String(m).padStart(2, "0") }),
              /* @__PURE__ */ jsx(Sep, {}),
              /* @__PURE__ */ jsx(Tile, { v: String(s).padStart(2, "0") })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "mt-2 flex gap-4 text-[9px] uppercase tracking-widest text-white/40", children: [
              /* @__PURE__ */ jsx("span", { className: "w-9 text-center", children: "Hrs" }),
              /* @__PURE__ */ jsx("span", { className: "w-9 text-center", children: "Min" }),
              /* @__PURE__ */ jsx("span", { className: "w-9 text-center", children: "Seg" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-2", children: [
            /* @__PURE__ */ jsx(Flag, { code: featured.away.code, size: 72 }),
            /* @__PURE__ */ jsx("span", { className: "font-display text-lg text-white", children: featured.away.short })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-5 flex items-center justify-between text-xs text-white/55", children: [
          /* @__PURE__ */ jsx("span", { children: featured.stadium }),
          /* @__PURE__ */ jsxs(Link, { to: "/matches", search: featured.stage === "group" ? {
            group: featured.group
          } : {
            stage: featured.stage
          }, className: "flex items-center gap-1 font-semibold text-primary", children: [
            "Predecir ahora ",
            /* @__PURE__ */ jsx(ChevronRight, { className: "h-3.5 w-3.5" })
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("section", { className: "mt-5 grid grid-cols-2 gap-3 px-4", children: [
      /* @__PURE__ */ jsx(StatCard, { icon: /* @__PURE__ */ jsx(Trophy, { className: "h-5 w-5" }), label: "Tu Posición", value: `#${userRank}`, accent: "gold" }),
      /* @__PURE__ */ jsx(StatCard, { icon: /* @__PURE__ */ jsx(Zap, { className: "h-5 w-5" }), label: "Precisión", value: `${stats.accuracy}%`, accent: "neon" })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "mt-5 px-4", children: /* @__PURE__ */ jsxs(Link, { to: "/champion", className: "glass-strong relative flex items-center gap-4 overflow-hidden rounded-3xl p-4 transition active:scale-[0.99]", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_100%_50%,oklch(0.9_0.18_85/0.18),transparent_60%)]" }),
      /* @__PURE__ */ jsx("div", { className: "relative grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-[oklch(0.9_0.18_85)] to-[oklch(0.65_0.18_60)]", children: /* @__PURE__ */ jsx(Trophy, { className: "h-7 w-7 text-[oklch(0.2_0.05_70)]", strokeWidth: 1.6 }) }),
      /* @__PURE__ */ jsxs("div", { className: "relative flex-1", children: [
        /* @__PURE__ */ jsx("div", { className: "text-[10px] font-bold uppercase tracking-widest text-[oklch(0.9_0.18_85)]", children: "Predicción Especial · 20 pts" }),
        /* @__PURE__ */ jsx("div", { className: "font-display text-xl text-white", children: "Elige al Campeón del Mundo" }),
        champion ? /* @__PURE__ */ jsxs("div", { className: "mt-0.5 flex items-center gap-1.5 text-xs text-white/60", children: [
          "Tu predicción: ",
          /* @__PURE__ */ jsx(Flag, { code: champion.code, size: 16 }),
          " ",
          /* @__PURE__ */ jsx("span", { className: "font-semibold text-white", children: champion.name })
        ] }) : /* @__PURE__ */ jsx("div", { className: "mt-0.5 text-xs text-white/55", children: "48 selecciones · 1 trofeo" })
      ] }),
      /* @__PURE__ */ jsx(ChevronRight, { className: "relative h-5 w-5 text-white/50" })
    ] }) }),
    /* @__PURE__ */ jsxs("section", { className: "mt-8 px-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-end justify-between gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxs("h2", { className: "font-display flex items-center gap-2 text-3xl text-white", children: [
            /* @__PURE__ */ jsx(Calendar, { className: "h-6 w-6 text-primary" }),
            " Partidos de Hoy"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50", children: "Predice antes del pitazo inicial" })
        ] }),
        /* @__PURE__ */ jsx(TimeFormatToggle, {})
      ] }),
      today.length > 0 ? /* @__PURE__ */ jsx("div", { className: "space-y-4", children: today.map((m2) => /* @__PURE__ */ jsx(MatchCard, { match: m2 }, m2.id)) }) : /* @__PURE__ */ jsxs("div", { className: "glass rounded-3xl p-5", children: [
        /* @__PURE__ */ jsx("div", { className: "text-[10px] uppercase tracking-widest text-white/45", children: "Sin partidos hoy" }),
        /* @__PURE__ */ jsx("div", { className: "mt-2 font-display text-xl text-white", children: "Próximo partido" }),
        /* @__PURE__ */ jsxs("div", { className: "mt-3 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Flag, { code: featured.home.code, size: 32 }),
          /* @__PURE__ */ jsx("span", { className: "font-display text-base text-white", children: featured.home.short }),
          /* @__PURE__ */ jsx("span", { className: "text-white/30", children: "vs" }),
          /* @__PURE__ */ jsx("span", { className: "font-display text-base text-white", children: featured.away.short }),
          /* @__PURE__ */ jsx(Flag, { code: featured.away.code, size: 32 })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-2 text-xs text-white/55", children: [
          formatDay(featured.kickoff),
          " · ",
          formatTime(featured.kickoff, format)
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "mt-8 px-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-end justify-between", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h2", { className: "font-display text-3xl text-white", children: "Próximos partidos" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50", children: "Guarda tus predicciones antes del pitazo inicial" })
        ] }),
        /* @__PURE__ */ jsx(Link, { to: "/matches", className: "text-xs font-semibold text-primary", children: "Ver todos →" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "space-y-4", children: upcoming.map((m2) => /* @__PURE__ */ jsx(MatchCard, { match: m2 }, m2.id)) })
    ] })
  ] });
}
function Tile({
  v
}) {
  return /* @__PURE__ */ jsx("div", { className: "glass grid h-12 w-9 place-items-center rounded-lg", children: /* @__PURE__ */ jsx("span", { className: "font-display text-2xl text-white", children: v }) });
}
function Sep() {
  return /* @__PURE__ */ jsx("span", { className: "font-display pb-1 text-2xl text-primary/70", children: ":" });
}
function StatCard({
  icon,
  label,
  value,
  accent
}) {
  return /* @__PURE__ */ jsxs("div", { className: "glass relative overflow-hidden rounded-2xl p-4", children: [
    /* @__PURE__ */ jsx("div", { className: `mb-2 grid h-9 w-9 place-items-center rounded-xl ${accent === "gold" ? "bg-[oklch(0.85_0.16_85/0.18)] text-[oklch(0.9_0.18_85)]" : "bg-primary/15 text-primary"}`, children: icon }),
    /* @__PURE__ */ jsx("div", { className: "text-[10px] uppercase tracking-widest text-white/50", children: label }),
    /* @__PURE__ */ jsx("div", { className: `font-display text-3xl ${accent === "gold" ? "text-gradient-gold" : "text-gradient-neon"}`, children: value })
  ] });
}
export {
  HomePage as component
};
