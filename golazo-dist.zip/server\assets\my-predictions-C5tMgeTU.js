import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Clock, Trophy, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { m as matches, p as predictionsStore, A as AppShell, d as calculateMatchPoints, i as isPredictionExact, e as isPredictionCorrect, F as Flag } from "./AppShell-B0dxobAF.js";
import { f as fetchRealGroupsAndMatches } from "./api-football-DNOoAqkn.js";
import { a as useTimeFormat, f as formatDay, b as formatTime } from "./router-Do2s6XFq.js";
import "@supabase/supabase-js";
import "sonner";
import "zod";
function MyPredictionsPage() {
  const {
    format
  } = useTimeFormat();
  const [filter, setFilter] = useState("all");
  const {
    data: apiData
  } = useQuery({
    queryKey: ["realMatchesAndGroups"],
    queryFn: fetchRealGroupsAndMatches,
    retry: 2,
    retryDelay: 2e3,
    staleTime: 0,
    gcTime: 0
  });
  const matchesList = apiData?.matches || matches;
  const userPredictions = predictionsStore.getAll();
  const predictedMatches = matchesList.filter((m) => userPredictions[m.id]);
  const filteredMatches = predictedMatches.filter((m) => {
    if (filter === "finished") {
      return m.status === "finished";
    }
    if (filter === "pending") {
      return m.status === "scheduled" || m.status === "live";
    }
    return true;
  });
  const sortedMatches = [...filteredMatches].sort((a, b) => {
    return new Date(b.kickoff).getTime() - new Date(a.kickoff).getTime();
  });
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsxs("header", { className: "px-5 pt-[max(28px,env(safe-area-inset-top))]", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx(Link, { to: "/profile", className: "glass grid h-9 w-9 place-items-center rounded-full hover:bg-white/15 transition active:scale-90", children: /* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4 text-white" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold uppercase tracking-[0.25em] text-primary", children: "Historial" }),
          /* @__PURE__ */ jsx("h1", { className: "font-display mt-0.5 text-4xl leading-none text-white", children: "Mis Pronósticos" })
        ] })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-xs text-white/55", children: "Compara lo que predijiste con los resultados oficiales de la FIFA en tiempo real." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "mt-6 flex gap-2 px-5", children: ["all", "finished", "pending"].map((f) => /* @__PURE__ */ jsx("button", { onClick: () => setFilter(f), className: `flex-1 rounded-2xl py-2 px-3 text-[11px] font-bold uppercase tracking-widest transition active:scale-95 text-center truncate ${filter === f ? "bg-primary text-primary-foreground neon-glow" : "glass text-white/70"}`, children: f === "all" ? "Todos" : f === "finished" ? "Finalizados" : "Pendientes" }, f)) }),
    /* @__PURE__ */ jsx("section", { className: "mt-6 px-4 mb-20 space-y-4", children: sortedMatches.length > 0 ? sortedMatches.map((match) => {
      const pred = userPredictions[match.id];
      const hasScore = match.status === "finished" || match.status === "live";
      const pts = calculateMatchPoints(match, pred);
      const exact = isPredictionExact(match, pred);
      isPredictionCorrect(match, pred);
      return /* @__PURE__ */ jsxs("div", { className: "glass relative overflow-hidden rounded-3xl p-4.5 flex flex-col gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-[9px] font-bold uppercase tracking-widest text-white/45", children: [
          /* @__PURE__ */ jsx("span", { className: "rounded-full bg-white/5 px-2 py-0.5", children: match.group ? `Grupo ${match.group}` : match.round }),
          /* @__PURE__ */ jsxs("span", { children: [
            formatDay(match.kickoff),
            " · ",
            formatTime(match.kickoff, format)
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3 py-1", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Flag, { code: match.home.code, size: 32 }),
            /* @__PURE__ */ jsx("span", { className: "font-display text-sm text-white truncate", children: match.home.short })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-col items-center", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[9px] uppercase tracking-widest text-primary font-bold", children: "Tu Pred" }),
              /* @__PURE__ */ jsxs("span", { className: "font-display text-xl font-extrabold text-white mt-0.5", children: [
                pred.home,
                " - ",
                pred.away
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "h-6 w-[1px] bg-white/10 self-end mb-1" }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "text-[9px] uppercase tracking-widest text-white/40", children: "Real" }),
              /* @__PURE__ */ jsx("span", { className: `font-display text-xl font-extrabold mt-0.5 ${hasScore ? "text-gradient-neon" : "text-white/20"}`, children: hasScore ? `${match.scoreHome} - ${match.scoreAway}` : "- - -" })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 flex-row-reverse text-right", children: [
            /* @__PURE__ */ jsx(Flag, { code: match.away.code, size: 32 }),
            /* @__PURE__ */ jsx("span", { className: "font-display text-sm text-white truncate", children: match.away.short })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "border-t border-white/5 pt-3 flex items-center justify-between", children: [
          /* @__PURE__ */ jsx("div", { children: match.status === "finished" ? /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white/50", children: "Finalizado" }) : match.status === "live" ? /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 rounded-full bg-red-500/15 px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-red-400 animate-pulse ring-1 ring-red-500/30", children: "En Juego" }) : /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white/35", children: "Pendiente" }) }),
          /* @__PURE__ */ jsx("div", { children: match.status === "finished" ? pts > 0 ? /* @__PURE__ */ jsxs("span", { className: `rounded-full px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider ${exact ? "bg-green-500/15 text-green-400 ring-1 ring-green-500/30 neon-glow" : "bg-primary/15 text-primary ring-1 ring-primary/30"}`, children: [
            "+",
            pts,
            " PTS (",
            exact ? "Exacto" : "Acierto",
            ")"
          ] }) : /* @__PURE__ */ jsx("span", { className: "rounded-full bg-white/5 px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider text-white/35", children: "0 PTS (Fallo)" }) : /* @__PURE__ */ jsxs("span", { className: "text-[10px] uppercase tracking-widest text-white/30 flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(Clock, { className: "h-3 w-3" }),
            " Esperando"
          ] }) })
        ] })
      ] }, match.id);
    }) : /* @__PURE__ */ jsxs("div", { className: "glass rounded-3xl p-8 text-center py-16", children: [
      /* @__PURE__ */ jsx(Trophy, { className: "h-12 w-12 text-white/20 mx-auto mb-4" }),
      /* @__PURE__ */ jsx("h3", { className: "font-display text-lg text-white", children: "Sin pronósticos" }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-white/50 mt-1 max-w-[220px] mx-auto", children: filter === "all" ? "No has guardado ninguna predicción para los partidos todavía." : filter === "finished" ? "No tienes predicciones en partidos que hayan finalizado." : "No tienes predicciones pendientes por jugar." }),
      filter === "all" && /* @__PURE__ */ jsxs(Link, { to: "/matches", className: "mt-6 inline-flex items-center gap-1.5 rounded-full bg-primary px-5 py-2.5 text-xs font-bold uppercase tracking-widest text-primary-foreground neon-glow", children: [
        "Hacer Predicciones ",
        /* @__PURE__ */ jsx(ChevronRight, { className: "h-3.5 w-3.5" })
      ] })
    ] }) })
  ] });
}
export {
  MyPredictionsPage as component
};
