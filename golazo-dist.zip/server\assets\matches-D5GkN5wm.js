import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Menu, User, Trophy } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { m as matches, a as groups, f as teamByCode, u as useAuth, A as AppShell, F as Flag, h as matchesByGroup, j as matchesByStage } from "./AppShell-B0dxobAF.js";
import { M as MatchCard } from "./MatchCard-CrBXoioB.js";
import { u as useSidebar, c as Route, T as TimeFormatToggle } from "./router-Do2s6XFq.js";
import { f as fetchRealGroupsAndMatches } from "./api-football-DNOoAqkn.js";
import "@supabase/supabase-js";
import "sonner";
import "zod";
const computeStandings = (groupName, matchesList = matches, groupsList = groups) => {
  const group = groupsList.find((g) => g.name === groupName);
  const teams = group ? group.teamCodes.map(teamByCode) : [];
  const rows = new Map(
    teams.map((t) => [t.code, { team: t, pj: 0, g: 0, e: 0, p: 0, gf: 0, gc: 0, dg: 0, pts: 0 }])
  );
  const played = matchesList.filter(
    (m) => m.group === groupName && m.status === "finished" && m.scoreHome != null && m.scoreAway != null
  );
  for (const m of played) {
    const home = rows.get(m.home.code);
    const away = rows.get(m.away.code);
    if (!home || !away) continue;
    home.pj++;
    away.pj++;
    home.gf += m.scoreHome;
    home.gc += m.scoreAway;
    away.gf += m.scoreAway;
    away.gc += m.scoreHome;
    if (m.scoreHome > m.scoreAway) {
      home.g++;
      away.p++;
      home.pts += 3;
    } else if (m.scoreHome < m.scoreAway) {
      away.g++;
      home.p++;
      away.pts += 3;
    } else {
      home.e++;
      away.e++;
      home.pts++;
      away.pts++;
    }
  }
  for (const r of rows.values()) r.dg = r.gf - r.gc;
  return Array.from(rows.values()).sort(
    (a, b) => b.pts - a.pts || b.dg - a.dg || b.gf - a.gf || a.team.name.localeCompare(b.team.name)
  );
};
const knockoutTabs = [{
  key: "round-of-32",
  label: "32avos"
}, {
  key: "round-of-16",
  label: "Octavos"
}, {
  key: "quarter-final",
  label: "Cuartos"
}, {
  key: "semi-final",
  label: "Semis"
}, {
  key: "third-place",
  label: "3er Lugar"
}, {
  key: "final",
  label: "Final"
}];
function MatchesPage() {
  const {
    open: openSidebar
  } = useSidebar();
  const {
    user,
    profile
  } = useAuth();
  const {
    data: apiData,
    isFetching
  } = useQuery({
    queryKey: ["realMatchesAndGroups"],
    queryFn: fetchRealGroupsAndMatches,
    retry: 2,
    retryDelay: 2e3,
    staleTime: 0,
    gcTime: 0
  });
  const matchesList = apiData?.matches || matches;
  const groupsList = apiData?.groups || groups;
  const search = Route.useSearch();
  const [mode, setMode] = useState("group");
  const [activeGroup, setActiveGroup] = useState("A");
  const [activeStage, setActiveStage] = useState("round-of-32");
  useEffect(() => {
    if (search.stage) {
      setMode("knockout");
      setActiveStage(search.stage);
    } else if (search.group) {
      setMode("group");
      setActiveGroup(search.group);
    }
  }, [search.stage, search.group]);
  useEffect(() => {
    if (apiData?.groups && apiData.groups.length > 0) {
      setActiveGroup((prev) => {
        const exists = apiData.groups.some((g) => g.name === prev);
        return exists ? prev : apiData.groups[0]?.name || prev;
      });
    }
  }, [apiData]);
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsxs("header", { className: "px-5 pt-[max(28px,env(safe-area-inset-top))]", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 mb-4", children: [
        /* @__PURE__ */ jsx("button", { onClick: openSidebar, title: "Menú", className: "glass grid h-9 w-9 place-items-center rounded-full hover:bg-white/15 transition", children: /* @__PURE__ */ jsx(Menu, { className: "h-4 w-4 text-white" }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsx(TimeFormatToggle, {}),
          /* @__PURE__ */ jsx(Link, { to: "/profile", className: "shrink-0 transition active:scale-95", children: user ? /* @__PURE__ */ jsx(Flag, { code: profile?.country_code || "cr", size: 32, className: "ring-2 ring-white/10" }) : /* @__PURE__ */ jsx("div", { className: "grid h-8 w-8 place-items-center rounded-full bg-white/5 border border-white/10 text-white/60", children: /* @__PURE__ */ jsx(User, { className: "h-4 w-4" }) }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("span", { className: "text-[11px] font-bold uppercase tracking-[0.25em] text-primary", children: mode === "group" ? "Fase de Grupos" : "Fase Final" }),
          /* @__PURE__ */ jsx("h1", { className: "font-display mt-1 text-5xl leading-none text-white", children: "Partidos" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-2 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("p", { className: "text-sm text-white/55", children: "Elige una fase. Predice cada partido." }),
            isFetching ? /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-primary", children: [
              /* @__PURE__ */ jsx("span", { className: "animate-pulse", children: "●" }),
              " Cargando..."
            ] }) : apiData ? /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 rounded-full bg-green-500/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-green-400", children: "● En vivo" }) : null
          ] })
        ] }),
        /* @__PURE__ */ jsx(TimeFormatToggle, {})
      ] }),
      /* @__PURE__ */ jsxs(Link, { to: "/champion", className: "mt-4 flex items-center gap-3 rounded-2xl bg-gradient-to-r from-[oklch(0.9_0.18_85/0.18)] to-[oklch(0.65_0.18_60/0.12)] px-4 py-3 ring-1 ring-[oklch(0.9_0.18_85/0.3)]", children: [
        /* @__PURE__ */ jsx(Trophy, { className: "h-5 w-5 text-[oklch(0.9_0.18_85)]" }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 text-xs", children: [
          /* @__PURE__ */ jsx("div", { className: "font-bold uppercase tracking-widest text-[oklch(0.9_0.18_85)]", children: "Campeón del Mundo · 20 pts" }),
          /* @__PURE__ */ jsx("div", { className: "text-white/60", children: "Elige a tu favorito para levantar la copa →" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "mt-5 flex gap-2 px-5", children: ["group", "knockout"].map((m) => /* @__PURE__ */ jsx("button", { onClick: () => setMode(m), className: `flex-1 rounded-2xl px-4 py-2.5 text-xs font-bold uppercase tracking-widest transition active:scale-95 ${mode === m ? "bg-primary text-primary-foreground neon-glow" : "glass text-white/70"}`, children: m === "group" ? "Grupos" : "Eliminatorias" }, m)) }),
    /* @__PURE__ */ jsx("div", { className: "mt-4 px-5", children: mode === "group" ? /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("div", { className: "text-[10px] font-bold uppercase tracking-widest text-white/40 mb-2", children: "Selecciona un Grupo" }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-6 gap-2", children: groupsList.map((g) => {
        const active = g.name === activeGroup;
        return /* @__PURE__ */ jsx("button", { onClick: () => setActiveGroup(g.name), className: `aspect-square rounded-2xl text-xs font-bold uppercase tracking-wide transition active:scale-90 flex items-center justify-center
                      ${active ? "bg-primary text-primary-foreground font-extrabold scale-105 neon-glow ring-2 ring-primary/40" : "glass text-white/75 hover:text-white hover:bg-white/10"}`, children: g.name }, g.name);
      }) })
    ] }) : /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("div", { className: "text-[10px] font-bold uppercase tracking-widest text-white/40 mb-2", children: "Fase Eliminatoria" }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 gap-2", children: knockoutTabs.map((t) => {
        const active = t.key === activeStage;
        return /* @__PURE__ */ jsx("button", { onClick: () => setActiveStage(t.key), className: `rounded-2xl py-2.5 px-1 text-[11px] font-bold uppercase tracking-wider transition active:scale-95 text-center truncate
                      ${active ? "bg-white text-black font-extrabold ring-2 ring-white/20" : "glass text-white/70 hover:text-white hover:bg-white/10"}`, children: t.label }, t.key);
      }) })
    ] }) }),
    mode === "group" ? /* @__PURE__ */ jsx(GroupView, { groupName: activeGroup, matchesList, groupsList }) : /* @__PURE__ */ jsx(StageView, { stage: activeStage, label: knockoutTabs.find((t) => t.key === activeStage).label, matchesList })
  ] });
}
function GroupView({
  groupName,
  matchesList,
  groupsList
}) {
  const rows = computeStandings(groupName, matchesList, groupsList);
  const groupMatches = matchesByGroup(groupName, matchesList);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("section", { className: "mt-6 px-4", children: /* @__PURE__ */ jsxs("div", { className: "glass overflow-hidden rounded-3xl", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b border-white/10 px-5 py-3", children: [
        /* @__PURE__ */ jsxs("span", { className: "font-display text-2xl text-white", children: [
          "Grupo ",
          groupName
        ] }),
        /* @__PURE__ */ jsx("span", { className: "text-[10px] uppercase tracking-widest text-white/45", children: "Tabla" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[28px_1fr_repeat(5,_28px)_36px] gap-2 px-5 py-2 text-[10px] uppercase tracking-widest text-white/40", children: [
        /* @__PURE__ */ jsx("span", { children: "#" }),
        /* @__PURE__ */ jsx("span", { children: "Equipo" }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: "PJ" }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: "G" }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: "E" }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: "P" }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: "DG" }),
        /* @__PURE__ */ jsx("span", { className: "text-right", children: "PTS" })
      ] }),
      /* @__PURE__ */ jsx("ul", { className: "divide-y divide-white/5", children: rows.map((r, i) => /* @__PURE__ */ jsxs("li", { className: "grid grid-cols-[28px_1fr_repeat(5,_28px)_36px] items-center gap-2 px-5 py-3 text-[11px] text-white/70", children: [
        /* @__PURE__ */ jsx("span", { className: `font-display ${i < 2 ? "text-primary" : "text-white/40"}`, children: i + 1 }),
        /* @__PURE__ */ jsxs("div", { className: "flex min-w-0 items-center gap-2", children: [
          /* @__PURE__ */ jsx(Flag, { code: r.team.code, size: 28 }),
          /* @__PURE__ */ jsx("span", { className: "truncate font-semibold text-white", children: r.team.name })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: r.pj }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: r.g }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: r.e }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: r.p }),
        /* @__PURE__ */ jsx("span", { className: "text-center", children: r.dg > 0 ? `+${r.dg}` : r.dg }),
        /* @__PURE__ */ jsx("span", { className: "text-right font-display text-base text-primary", children: r.pts })
      ] }, r.team.code)) })
    ] }) }),
    /* @__PURE__ */ jsxs("section", { className: "mt-8 space-y-4 px-4", children: [
      /* @__PURE__ */ jsxs("h2", { className: "px-1 font-display text-2xl text-white", children: [
        "Partidos del Grupo ",
        groupName
      ] }),
      groupMatches.map((m) => /* @__PURE__ */ jsx(MatchCard, { match: m }, m.id))
    ] })
  ] });
}
function StageView({
  stage,
  label,
  matchesList
}) {
  const list = matchesByStage(stage, matchesList);
  return /* @__PURE__ */ jsxs("section", { className: "mt-6 space-y-4 px-4", children: [
    /* @__PURE__ */ jsx("h2", { className: "px-1 font-display text-2xl text-white", children: label }),
    list.map((m) => /* @__PURE__ */ jsx(MatchCard, { match: m }, m.id))
  ] });
}
export {
  MatchesPage as component
};
