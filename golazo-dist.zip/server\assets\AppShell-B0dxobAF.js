import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useRouterState, Link } from "@tanstack/react-router";
import { Home, Trophy, User, X, ChevronRight, FileText, BookOpen, ShieldCheck, Settings, LogOut } from "lucide-react";
import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import { toast } from "sonner";
import { u as useSidebar } from "./router-Do2s6XFq.js";
function Ball$1({ className = "" }) {
  return /* @__PURE__ */ jsxs("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", className, children: [
    /* @__PURE__ */ jsx("circle", { cx: "12", cy: "12", r: "9" }),
    /* @__PURE__ */ jsx("path", { d: "M12 3l3 4-1.5 5h-3L9 7z" }),
    /* @__PURE__ */ jsx("path", { d: "M3.5 10l3.5 2 2 5-2 2.5" }),
    /* @__PURE__ */ jsx("path", { d: "M20.5 10L17 12l-2 5 2 2.5" }),
    /* @__PURE__ */ jsx("path", { d: "M9 7L5 8.5" }),
    /* @__PURE__ */ jsx("path", { d: "M15 7l4 1.5" })
  ] });
}
const items = [
  { to: "/", label: "Inicio", Icon: Home },
  { to: "/matches", label: "Partidos", Icon: Ball$1 },
  { to: "/ranking", label: "Ranking", Icon: Trophy },
  { to: "/profile", label: "Perfil", Icon: User }
];
function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return /* @__PURE__ */ jsx("nav", { className: "fixed bottom-0 left-0 right-0 z-50 bg-[#070b0e]/95 backdrop-blur-xl border-t border-white/10 px-4 pt-2 pb-[max(8px,env(safe-area-inset-bottom))]", children: /* @__PURE__ */ jsx("div", { className: "mx-auto flex max-w-md items-center justify-between gap-1", children: items.map(({ to, label, Icon }) => {
    const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
    return /* @__PURE__ */ jsxs(
      Link,
      {
        to,
        className: "group relative flex flex-1 flex-col items-center gap-1 py-1.5 transition",
        children: [
          active && /* @__PURE__ */ jsx("span", { className: "absolute -top-2 left-1/2 -translate-x-1/2 h-[3px] w-8 rounded-full bg-primary neon-glow" }),
          /* @__PURE__ */ jsx(
            Icon,
            {
              className: `h-5.5 w-5.5 transition-all duration-300 ${active ? "text-primary drop-shadow-[0_0_8px_oklch(0.86_0.22_152/0.5)] scale-105" : "text-white/50 group-hover:text-white/80"}`
            }
          ),
          /* @__PURE__ */ jsx(
            "span",
            {
              className: `text-[9px] font-bold uppercase tracking-widest transition-colors duration-300 ${active ? "text-primary" : "text-white/40 group-hover:text-white/60"}`,
              children: label
            }
          )
        ]
      },
      to
    );
  }) }) });
}
const supabaseUrl = "https://qposmttwhgjhytoyjgzs.supabase.co/rest/v1/".trim();
const cleanUrl = supabaseUrl.replace(/\/rest\/v1\/?$/, "");
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwb3NtdHR3aGdqaHl0b3lqZ3pzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE5MTI3NTMsImV4cCI6MjA5NzQ4ODc1M30.mcmVffAeinr4If9iyC36JTG3QhYtSs_wqMdbzJ54hJg".trim();
if (!cleanUrl || !supabaseAnonKey) {
  console.warn(
    "[Supabase] Advertencia: VITE_SUPABASE_URL o VITE_SUPABASE_ANON_KEY no están configurados en el archivo .env"
  );
}
const supabase = createClient(cleanUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});
const KEY_PREDICTIONS = "golazo:predictions";
const KEY_CHAMPION = "golazo:champion";
const listeners = /* @__PURE__ */ new Set();
const notify = () => listeners.forEach((l) => l());
const read = (key, fallback) => {
  if (typeof window === "undefined") return fallback;
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
};
const write = (key, val) => {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch {
  }
};
const predictionsStore = {
  getAll() {
    return read(KEY_PREDICTIONS, {});
  },
  get(matchId) {
    return this.getAll()[matchId];
  },
  set(matchId, p) {
    const all = this.getAll();
    all[matchId] = p;
    write(KEY_PREDICTIONS, all);
    notify();
  },
  setAll(preds) {
    write(KEY_PREDICTIONS, preds);
    notify();
  },
  clear() {
    write(KEY_PREDICTIONS, {});
    write(KEY_CHAMPION, null);
    notify();
  },
  getChampion() {
    return read(KEY_CHAMPION, null);
  },
  setChampion(code) {
    write(KEY_CHAMPION, code);
    notify();
  },
  subscribe(l) {
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }
};
function useChampion() {
  const [code, setCode] = useState(null);
  useEffect(() => {
    setCode(predictionsStore.getChampion());
    return predictionsStore.subscribe(() => setCode(predictionsStore.getChampion()));
  }, []);
  return code;
}
function calculateMatchPoints(match, pred) {
  if (!pred || match.status !== "finished" || match.scoreHome == null || match.scoreAway == null) {
    return 0;
  }
  const isKnockout = match.stage !== "group";
  const exact = pred.home === match.scoreHome && pred.away === match.scoreAway;
  if (exact) {
    return isKnockout ? 5 : 3;
  }
  const predOutcome = Math.sign(pred.home - pred.away);
  const realOutcome = Math.sign(match.scoreHome - match.scoreAway);
  if (predOutcome === realOutcome) {
    return isKnockout ? 3 : 1;
  }
  return 0;
}
function isPredictionCorrect(match, pred) {
  if (!pred || match.status !== "finished" || match.scoreHome == null || match.scoreAway == null) {
    return false;
  }
  const predOutcome = Math.sign(pred.home - pred.away);
  const realOutcome = Math.sign(match.scoreHome - match.scoreAway);
  return predOutcome === realOutcome;
}
function isPredictionExact(match, pred) {
  if (!pred || match.status !== "finished" || match.scoreHome == null || match.scoreAway == null) {
    return false;
  }
  return pred.home === match.scoreHome && pred.away === match.scoreAway;
}
function calculateUserStats(matches2) {
  const predictions = predictionsStore.getAll();
  let totalPredictions = 0;
  let correct = 0;
  let exact = 0;
  let points = 0;
  for (const m of matches2) {
    const pred = predictions[m.id];
    if (pred) {
      totalPredictions++;
      if (m.status === "finished") {
        const pts = calculateMatchPoints(m, pred);
        points += pts;
        if (isPredictionExact(m, pred)) {
          exact++;
          correct++;
        } else if (isPredictionCorrect(m, pred)) {
          correct++;
        }
      }
    }
  }
  const championCode = predictionsStore.getChampion();
  if (championCode) {
    const finalMatch = matches2.find((m) => m.stage === "final");
    if (finalMatch && finalMatch.status === "finished" && finalMatch.scoreHome != null && finalMatch.scoreAway != null) {
      let winnerCode = "";
      if (finalMatch.scoreHome > finalMatch.scoreAway) {
        winnerCode = finalMatch.home.code;
      } else if (finalMatch.scoreAway > finalMatch.scoreHome) {
        winnerCode = finalMatch.away.code;
      }
      if (winnerCode && winnerCode === championCode) {
        points += 20;
      }
    }
  }
  const finishedPredictionsCount = matches2.filter((m) => m.status === "finished" && predictions[m.id]).length;
  const accuracy = finishedPredictionsCount > 0 ? Math.round(correct / finishedPredictionsCount * 100) : 0;
  return {
    predictions: totalPredictions,
    correct,
    exact,
    accuracy,
    points
  };
}
function useAuth() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const fetchProfile = async (userId) => {
    try {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single();
      if (error) {
        console.warn("No se encontró el perfil en la base de datos:", error.message);
        setProfile(null);
      } else {
        setProfile(data);
      }
    } catch (err) {
      console.error("Error al obtener perfil de Supabase:", err);
      setProfile(null);
    }
  };
  const syncPredictions = async (userId) => {
    try {
      const { data: dbPreds, error } = await supabase.from("predictions").select("match_id, home_score, away_score").eq("user_id", userId);
      if (error) throw error;
      const local = predictionsStore.getAll();
      const map = {};
      if (dbPreds) {
        dbPreds.forEach((p) => {
          map[p.match_id] = { home: p.home_score, away: p.away_score };
        });
      }
      const toUpload = [];
      Object.entries(local).forEach(([matchId, p]) => {
        if (!map[matchId]) {
          map[matchId] = p;
          toUpload.push({
            user_id: userId,
            match_id: matchId,
            home_score: p.home,
            away_score: p.away
          });
        }
      });
      if (toUpload.length > 0) {
        console.log("[Sync] Subiendo predicciones locales a Supabase:", toUpload.length);
        await supabase.from("predictions").upsert(toUpload);
      }
      predictionsStore.setAll(map);
    } catch (err) {
      console.error("Error al sincronizar predicciones con Supabase:", err);
    }
  };
  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!active) return;
      setUser(session?.user ?? null);
      if (session?.user) {
        await Promise.all([
          fetchProfile(session.user.id),
          syncPredictions(session.user.id)
        ]);
      }
      setLoading(false);
    });
    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!active) return;
      console.log("[Auth Change Event]:", event);
      setUser(session?.user ?? null);
      if (session?.user) {
        setLoading(true);
        await Promise.all([
          fetchProfile(session.user.id),
          syncPredictions(session.user.id)
        ]);
        setLoading(false);
      } else {
        setProfile(null);
        predictionsStore.clear();
        setLoading(false);
      }
    });
    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);
  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  };
  return {
    user,
    profile,
    loading,
    refreshProfile
  };
}
const teams = [
  // CONMEBOL
  { code: "ar", name: "Argentina", short: "ARG", confederation: "CONMEBOL" },
  { code: "br", name: "Brasil", short: "BRA", confederation: "CONMEBOL" },
  { code: "uy", name: "Uruguay", short: "URU", confederation: "CONMEBOL" },
  { code: "co", name: "Colombia", short: "COL", confederation: "CONMEBOL" },
  { code: "ec", name: "Ecuador", short: "ECU", confederation: "CONMEBOL" },
  { code: "cl", name: "Chile", short: "CHI", confederation: "CONMEBOL" },
  { code: "pe", name: "Perú", short: "PER", confederation: "CONMEBOL" },
  { code: "py", name: "Paraguay", short: "PAR", confederation: "CONMEBOL" },
  // CONCACAF
  { code: "mx", name: "México", short: "MEX", confederation: "CONCACAF" },
  { code: "us", name: "Estados Unidos", short: "EUA", confederation: "CONCACAF" },
  { code: "ca", name: "Canadá", short: "CAN", confederation: "CONCACAF" },
  { code: "cr", name: "Costa Rica", short: "CRC", confederation: "CONCACAF" },
  { code: "pa", name: "Panamá", short: "PAN", confederation: "CONCACAF" },
  { code: "jm", name: "Jamaica", short: "JAM", confederation: "CONCACAF" },
  { code: "hn", name: "Honduras", short: "HON", confederation: "CONCACAF" },
  // UEFA
  { code: "es", name: "España", short: "ESP", confederation: "UEFA" },
  { code: "fr", name: "Francia", short: "FRA", confederation: "UEFA" },
  { code: "de", name: "Alemania", short: "ALE", confederation: "UEFA" },
  { code: "gb-eng", name: "Inglaterra", short: "ING", confederation: "UEFA" },
  { code: "it", name: "Italia", short: "ITA", confederation: "UEFA" },
  { code: "pt", name: "Portugal", short: "POR", confederation: "UEFA" },
  { code: "nl", name: "Países Bajos", short: "NED", confederation: "UEFA" },
  { code: "be", name: "Bélgica", short: "BEL", confederation: "UEFA" },
  { code: "hr", name: "Croacia", short: "CRO", confederation: "UEFA" },
  { code: "ch", name: "Suiza", short: "SUI", confederation: "UEFA" },
  { code: "dk", name: "Dinamarca", short: "DIN", confederation: "UEFA" },
  { code: "pl", name: "Polonia", short: "POL", confederation: "UEFA" },
  { code: "rs", name: "Serbia", short: "SRB", confederation: "UEFA" },
  { code: "se", name: "Suecia", short: "SUE", confederation: "UEFA" },
  { code: "at", name: "Austria", short: "AUT", confederation: "UEFA" },
  // CAF
  { code: "ma", name: "Marruecos", short: "MAR", confederation: "CAF" },
  { code: "sn", name: "Senegal", short: "SEN", confederation: "CAF" },
  { code: "tn", name: "Túnez", short: "TUN", confederation: "CAF" },
  { code: "eg", name: "Egipto", short: "EGI", confederation: "CAF" },
  { code: "ng", name: "Nigeria", short: "NGA", confederation: "CAF" },
  { code: "cm", name: "Camerún", short: "CAM", confederation: "CAF" },
  { code: "gh", name: "Ghana", short: "GHA", confederation: "CAF" },
  { code: "ci", name: "Costa de Marfil", short: "CIV", confederation: "CAF" },
  { code: "dz", name: "Argelia", short: "ARG", confederation: "CAF" },
  // AFC
  { code: "jp", name: "Japón", short: "JPN", confederation: "AFC" },
  { code: "kr", name: "Corea del Sur", short: "KOR", confederation: "AFC" },
  { code: "sa", name: "Arabia Saudita", short: "KSA", confederation: "AFC" },
  { code: "ir", name: "Irán", short: "IRN", confederation: "AFC" },
  { code: "qa", name: "Catar", short: "QAT", confederation: "AFC" },
  { code: "au", name: "Australia", short: "AUS", confederation: "AFC" },
  { code: "ae", name: "Emiratos Árabes", short: "EAU", confederation: "AFC" },
  { code: "uz", name: "Uzbekistán", short: "UZB", confederation: "AFC" },
  // OFC
  { code: "nz", name: "Nueva Zelanda", short: "NZL", confederation: "OFC" },
  // Adicionales Mundial 2026
  { code: "za", name: "Sudáfrica", short: "RSA", confederation: "CAF" },
  { code: "cz", name: "Rep. Checa", short: "CZE", confederation: "UEFA" },
  { code: "ba", name: "Bosnia y Herz.", short: "BIH", confederation: "UEFA" },
  { code: "tr", name: "Turquía", short: "TUR", confederation: "UEFA" },
  { code: "ht", name: "Haití", short: "HAI", confederation: "CONCACAF" },
  { code: "gb-sct", name: "Escocia", short: "ESC", confederation: "UEFA" },
  { code: "no", name: "Noruega", short: "NOR", confederation: "UEFA" },
  { code: "cw", name: "Curazao", short: "CUR", confederation: "CONCACAF" },
  { code: "cv", name: "Cabo Verde", short: "CPV", confederation: "CAF" },
  { code: "cd", name: "Congo", short: "COD", confederation: "CAF" },
  { code: "iq", name: "Iraq", short: "IRQ", confederation: "AFC" },
  { code: "jo", name: "Jordania", short: "JOR", confederation: "AFC" }
];
const teamByCode = (code) => teams.find((t) => t.code === code) ?? {
  code: "tbd",
  name: "Por definir",
  short: "TBD",
  confederation: "UEFA"
};
const flagUrl = (code, size = 80) => code === "tbd" ? `data:image/svg+xml;utf8,${encodeURIComponent(
  `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80'><rect width='80' height='80' fill='%23111'/><text x='50%' y='55%' font-family='sans-serif' font-size='28' fill='%2300d68f' text-anchor='middle'>?</text></svg>`
)}` : `https://flagcdn.com/w${size}/${code}.png`;
const groups = [
  { name: "A", teamCodes: ["mx", "za", "kr", "cz"] },
  // México, Sudáfrica, Corea del Sur, Rep. Checa
  { name: "B", teamCodes: ["ca", "ba", "qa", "ch"] },
  // Canadá, Bosnia, Qatar, Suiza
  { name: "C", teamCodes: ["br", "ma", "ht", "gb-sct"] },
  // Brasil, Marruecos, Haití, Escocia
  { name: "D", teamCodes: ["us", "py", "au", "tr"] },
  // Estados Unidos, Paraguay, Australia, Turquía
  { name: "E", teamCodes: ["de", "cw", "ci", "ec"] },
  // Alemania, Curazao, Costa de Marfil, Ecuador
  { name: "F", teamCodes: ["nl", "jp", "se", "tn"] },
  // Países Bajos, Japón, Suecia, Túnez
  { name: "G", teamCodes: ["be", "eg", "ir", "nz"] },
  // Bélgica, Egipto, Irán, Nueva Zelanda
  { name: "H", teamCodes: ["es", "cv", "sa", "uy"] },
  // España, Cabo Verde, Arabia Saudita, Uruguay
  { name: "I", teamCodes: ["fr", "sn", "iq", "no"] },
  // Francia, Senegal, Iraq, Noruega
  { name: "J", teamCodes: ["ar", "dz", "at", "jo"] },
  // Argentina, Argelia, Austria, Jordania
  { name: "K", teamCodes: ["pt", "cd", "uz", "co"] },
  // Portugal, Congo, Uzbekistán, Colombia
  { name: "L", teamCodes: ["gb-eng", "hr", "gh", "pa"] }
  // Inglaterra, Croacia, Ghana, Panamá
];
if (typeof window !== "undefined") {
  const codes = groups.flatMap((g) => g.teamCodes);
  const unique = new Set(codes);
  if (codes.length !== 48 || unique.size !== 48) {
    console.warn("[groups] Se esperaban 48 equipos únicos; hay", codes.length, "y", unique.size, "únicos");
  }
}
const venues = [
  { stadium: "MetLife Stadium", city: "Nueva York" },
  { stadium: "SoFi Stadium", city: "Los Ángeles" },
  { stadium: "AT&T Stadium", city: "Dallas" },
  { stadium: "Mercedes-Benz Stadium", city: "Atlanta" },
  { stadium: "Lincoln Financial Field", city: "Filadelfia" },
  { stadium: "Hard Rock Stadium", city: "Miami" },
  { stadium: "Levi's Stadium", city: "San Francisco" },
  { stadium: "Lumen Field", city: "Seattle" },
  { stadium: "NRG Stadium", city: "Houston" },
  { stadium: "Arrowhead Stadium", city: "Kansas City" },
  { stadium: "Gillette Stadium", city: "Boston" },
  { stadium: "BMO Field", city: "Toronto" },
  { stadium: "BC Place", city: "Vancouver" },
  { stadium: "Estadio Azteca", city: "Ciudad de México" },
  { stadium: "Estadio Akron", city: "Guadalajara" },
  { stadium: "Estadio BBVA", city: "Monterrey" }
];
const TOURNAMENT_START = /* @__PURE__ */ new Date("2026-06-11T17:00:00Z");
const isoFromOffset = (dayOffset, hour) => {
  const d = new Date(TOURNAMENT_START);
  d.setUTCDate(d.getUTCDate() + dayOffset);
  d.setUTCHours(hour, 0, 0, 0);
  return d.toISOString();
};
const roundRobinPairs = (codes) => [
  { round: "Jornada 1", pairs: [[codes[0], codes[1]], [codes[2], codes[3]]] },
  { round: "Jornada 2", pairs: [[codes[0], codes[2]], [codes[3], codes[1]]] },
  { round: "Jornada 3", pairs: [[codes[0], codes[3]], [codes[1], codes[2]]] }
];
const buildGroupStage = () => {
  const out = [];
  let venueIdx = 0;
  groups.forEach((g, gi) => {
    const rounds = roundRobinPairs(g.teamCodes);
    rounds.forEach((r, ri) => {
      r.pairs.forEach((pair, pi) => {
        const dayOffset = gi % 12 + ri * 4 + Math.floor(gi / 6);
        const hour = 17 + pi * 3;
        const venue = venues[venueIdx % venues.length];
        venueIdx++;
        out.push({
          id: `G${g.name}-J${ri + 1}-${pi + 1}`,
          stage: "group",
          group: g.name,
          round: r.round,
          home: teamByCode(pair[0]),
          away: teamByCode(pair[1]),
          stadium: venue.stadium,
          city: venue.city,
          kickoff: isoFromOffset(dayOffset, hour),
          status: "scheduled"
        });
      });
    });
  });
  return out;
};
const tbd = (label) => ({
  code: "tbd",
  name: label,
  short: label,
  confederation: "UEFA"
});
const buildKnockout = () => {
  const out = [];
  let venueIdx = 0;
  const addStage = (stage, round, count, baseDay, labeler) => {
    for (let i = 0; i < count; i++) {
      const venue = venues[venueIdx % venues.length];
      venueIdx++;
      const [h, a] = labeler(i);
      out.push({
        id: `${stage}-${i + 1}`,
        stage,
        round,
        home: tbd(h),
        away: tbd(a),
        stadium: venue.stadium,
        city: venue.city,
        kickoff: isoFromOffset(baseDay + Math.floor(i / 2), 17 + i % 2 * 3),
        status: "scheduled"
      });
    }
  };
  const groupLetters = groups.map((g) => g.name);
  addStage("round-of-32", "Dieciseisavos", 16, 15, (i) => {
    const a = groupLetters[i % 12];
    const b = groupLetters[(i + 6) % 12];
    return [`1° Grupo ${a}`, `2° Grupo ${b}`];
  });
  addStage("round-of-16", "Octavos", 8, 22, (i) => [
    `Ganador 32-${i * 2 + 1}`,
    `Ganador 32-${i * 2 + 2}`
  ]);
  addStage("quarter-final", "Cuartos", 4, 27, (i) => [
    `Ganador 16-${i * 2 + 1}`,
    `Ganador 16-${i * 2 + 2}`
  ]);
  addStage("semi-final", "Semifinal", 2, 31, (i) => [
    `Ganador CF-${i * 2 + 1}`,
    `Ganador CF-${i * 2 + 2}`
  ]);
  addStage("third-place", "Tercer Lugar", 1, 34, () => ["Perdedor SF-1", "Perdedor SF-2"]);
  addStage("final", "Final", 1, 35, () => ["Ganador SF-1", "Ganador SF-2"]);
  return out;
};
const matches = [...buildGroupStage(), ...buildKnockout()];
const matchesByGroup = (groupName, list = matches) => list.filter((m) => m.group === groupName);
const matchesByStage = (stage, list = matches) => list.filter((m) => m.stage === stage);
const upcomingMatches = (limit, list = matches) => {
  const now = Date.now();
  const sorted = list.filter((m) => m.status === "scheduled" && new Date(m.kickoff).getTime() >= now).sort((a, b) => +new Date(a.kickoff) - +new Date(b.kickoff));
  return limit ? sorted.slice(0, limit) : sorted;
};
const nextMatch = (list = matches) => upcomingMatches(1, list)[0] ?? list[0];
const seed = [
  { name: "Lucas Silva", country: "br", points: 1248, accuracy: 78, streak: 7 },
  { name: "Sofía Müller", country: "de", points: 1236, accuracy: 74, streak: 4 },
  { name: "Hiro Tanaka", country: "jp", points: 1224, accuracy: 71, streak: 5 },
  { name: "Emma Dubois", country: "fr", points: 1210, accuracy: 69, streak: 2 },
  { name: "Tú", country: "mx", points: 1198, accuracy: 67, streak: 3, isYou: true },
  { name: "Mateo Rossi", country: "it", points: 1191, accuracy: 65, streak: 1 },
  { name: "Olivia García", country: "es", points: 1184, accuracy: 63, streak: 0 },
  { name: "Ahmed Hassan", country: "eg", points: 1172, accuracy: 60, streak: 2 },
  { name: "Chen Wei", country: "cn", points: 1165, accuracy: 58, streak: 1 },
  { name: "Liam O'Connor", country: "ie", points: 1158, accuracy: 56, streak: 0 },
  { name: "Camila Torres", country: "ar", points: 1142, accuracy: 55, streak: 2 },
  { name: "Noah Andersson", country: "se", points: 1128, accuracy: 53, streak: 0 },
  { name: "Aya Benali", country: "ma", points: 1115, accuracy: 52, streak: 1 },
  { name: "Diego Suárez", country: "uy", points: 1101, accuracy: 51, streak: 3 },
  { name: "Min-jun Park", country: "kr", points: 1089, accuracy: 49, streak: 0 },
  { name: "Sara Novak", country: "hr", points: 1075, accuracy: 48, streak: 1 },
  { name: "Carlos Mendoza", country: "co", points: 1062, accuracy: 47, streak: 0 },
  { name: "Yara Haddad", country: "sa", points: 1048, accuracy: 46, streak: 2 },
  { name: "Tomás Pereira", country: "pt", points: 1031, accuracy: 44, streak: 0 },
  { name: "Isabella Rossi", country: "ch", points: 1018, accuracy: 43, streak: 1 }
];
const leaderboard = seed.sort((a, b) => b.points - a.points).map((entry, i) => ({ ...entry, rank: i + 1 }));
function getMockPrediction(playerName, matchId) {
  let hash = 0;
  const str = playerName + matchId;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const home = Math.abs(hash) % 4;
  const away = Math.abs(hash >> 2) % 4;
  return { home, away };
}
function getDynamicLeaderboard(matchesList) {
  const finished = matchesList.filter((m) => m.status === "finished");
  if (finished.length === 0) {
    return leaderboard;
  }
  const userPredictions = predictionsStore.getAll();
  const entries = seed.map((player) => {
    if (player.isYou) {
      let pts = 0;
      let correct = 0;
      let finishedPreds = 0;
      for (const m of matchesList) {
        const pred = userPredictions[m.id];
        if (pred) {
          if (m.status === "finished") {
            finishedPreds++;
            const matchPts = calculateMatchPoints(m, pred);
            pts += matchPts;
            if (isPredictionExact(m, pred)) {
              correct++;
            } else if (isPredictionCorrect(m, pred)) {
              correct++;
            }
          }
        }
      }
      const championCode = predictionsStore.getChampion();
      if (championCode) {
        const finalMatch = matchesList.find((m) => m.stage === "final");
        if (finalMatch && finalMatch.status === "finished" && finalMatch.scoreHome != null && finalMatch.scoreAway != null) {
          let winnerCode = "";
          if (finalMatch.scoreHome > finalMatch.scoreAway) {
            winnerCode = finalMatch.home.code;
          } else if (finalMatch.scoreAway > finalMatch.scoreHome) {
            winnerCode = finalMatch.away.code;
          }
          if (winnerCode === championCode) {
            pts += 20;
          }
        }
      }
      const accuracy = finishedPreds > 0 ? Math.round(correct / finishedPreds * 100) : 0;
      return {
        ...player,
        points: pts,
        accuracy,
        streak: 0
      };
    } else {
      let pts = 0;
      let correct = 0;
      let finishedPreds = 0;
      for (const m of matchesList) {
        if (m.status === "finished") {
          const pred = getMockPrediction(player.name, m.id);
          finishedPreds++;
          const matchPts = calculateMatchPoints(m, pred);
          pts += matchPts;
          if (isPredictionExact(m, pred)) {
            correct++;
          } else if (isPredictionCorrect(m, pred)) {
            correct++;
          }
        }
      }
      const accuracy = finishedPreds > 0 ? Math.round(correct / finishedPreds * 100) : 0;
      return {
        ...player,
        points: pts,
        accuracy,
        streak: Math.min(5, Math.max(0, pts % 3))
      };
    }
  });
  return entries.sort((a, b) => b.points - a.points || b.accuracy - a.accuracy || a.name.localeCompare(b.name)).map((entry, i) => ({ ...entry, rank: i + 1 }));
}
async function getSupabaseLeaderboard(matchesList, currentUserId) {
  try {
    const { data: dbProfiles, error: pError } = await supabase.from("profiles").select("*");
    if (pError) throw pError;
    const { data: dbPredictions, error: predError } = await supabase.from("predictions").select("*");
    if (predError) throw predError;
    const realEntries = (dbProfiles || []).map((profile) => {
      const userPreds = (dbPredictions || []).filter((p) => p.user_id === profile.id);
      let pts = 0;
      let correct = 0;
      let exact = 0;
      let finishedPreds = 0;
      for (const m of matchesList) {
        const pred = userPreds.find((p) => p.match_id === m.id);
        if (pred) {
          if (m.status === "finished") {
            finishedPreds++;
            const matchPts = calculateMatchPoints(m, { home: pred.home_score, away: pred.away_score });
            pts += matchPts;
            if (pred.home_score === m.scoreHome && pred.away_score === m.scoreAway) {
              exact++;
              correct++;
            } else if (m.scoreHome !== void 0 && m.scoreAway !== void 0) {
              const predOutcome = Math.sign(pred.home_score - pred.away_score);
              const realOutcome = Math.sign(m.scoreHome - m.scoreAway);
              if (predOutcome === realOutcome) {
                correct++;
              }
            }
          }
        }
      }
      const accuracy = finishedPreds > 0 ? Math.round(correct / finishedPreds * 100) : 0;
      return {
        rank: 0,
        name: profile.full_name || profile.username,
        country: profile.country_code || "cr",
        points: pts,
        accuracy,
        streak: 0,
        isYou: profile.id === currentUserId
      };
    });
    return realEntries.sort((a, b) => b.points - a.points || b.accuracy - a.accuracy || a.name.localeCompare(b.name)).map((entry, i) => ({ ...entry, rank: i + 1 }));
  } catch (err) {
    console.error("Error al calcular ranking de Supabase:", err);
    return getDynamicLeaderboard(matchesList);
  }
}
function Flag({ code, size = 48, className = "" }) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: `relative shrink-0 overflow-hidden rounded-full ring-2 ring-white/15 shadow-lg ${className}`,
      style: { width: size, height: size },
      children: [
        /* @__PURE__ */ jsx(
          "img",
          {
            src: flagUrl(code, size > 60 ? 160 : 80),
            alt: `Bandera ${code}`,
            width: size,
            height: size,
            loading: "lazy",
            className: "h-full w-full object-cover"
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 rounded-full bg-gradient-to-b from-white/15 via-transparent to-black/30" })
      ]
    }
  );
}
function Ball({ className = "" }) {
  return /* @__PURE__ */ jsxs("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", className, children: [
    /* @__PURE__ */ jsx("circle", { cx: "12", cy: "12", r: "9" }),
    /* @__PURE__ */ jsx("path", { d: "M12 3l3 4-1.5 5h-3L9 7z" }),
    /* @__PURE__ */ jsx("path", { d: "M3.5 10l3.5 2 2 5-2 2.5" }),
    /* @__PURE__ */ jsx("path", { d: "M20.5 10L17 12l-2 5 2 2.5" }),
    /* @__PURE__ */ jsx("path", { d: "M9 7L5 8.5" }),
    /* @__PURE__ */ jsx("path", { d: "M15 7l4 1.5" })
  ] });
}
function Sidebar({ isOpen, onClose }) {
  const { user, profile } = useAuth();
  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      toast.info("Sesión cerrada correctamente");
      onClose();
    } catch (err) {
      toast.error("Error al cerrar sesión: " + (err.message || err));
    }
  };
  const navItems = [
    { to: "/", label: "Inicio", Icon: Home },
    { to: "/matches", label: "Partidos", Icon: Ball },
    { to: "/ranking", label: "Ranking", Icon: Trophy },
    { to: "/profile", label: "Mi Perfil", Icon: User },
    { to: "/my-predictions", label: "Mis Pronósticos", Icon: FileText },
    { to: "/champion", label: "Campeón Mundial", Icon: Trophy, isSpecial: true }
  ];
  const legalItems = [
    { to: "/rules", search: { tab: "manual" }, label: "Manual de Juego", Icon: BookOpen },
    { to: "/rules", search: { tab: "terms" }, label: "Términos y Condiciones", Icon: FileText },
    { to: "/rules", search: { tab: "privacy" }, label: "Privacidad", Icon: ShieldCheck }
  ];
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "div",
      {
        className: `fixed inset-0 z-50 bg-black/60 backdrop-blur-xs transition-opacity duration-300 ${isOpen ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"}`,
        onClick: onClose
      }
    ),
    /* @__PURE__ */ jsxs(
      "aside",
      {
        className: `fixed bottom-0 top-0 left-0 z-50 w-[280px] bg-[#0a0f14] border-r border-white/10 flex flex-col justify-between transition-transform duration-300 ease-out transform ${isOpen ? "translate-x-0" : "-translate-x-full"}`,
        children: [
          /* @__PURE__ */ jsxs("div", { className: "p-5 border-b border-white/10 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx("span", { className: "grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground font-display text-base", children: "G" }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("span", { className: "font-display text-lg tracking-wide text-white block leading-none", children: "GOLAZO" }),
                /* @__PURE__ */ jsx("span", { className: "text-[9px] uppercase tracking-widest text-white/40", children: "Mundial 2026" })
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: onClose,
                className: "grid h-8 w-8 place-items-center rounded-lg bg-white/5 border border-white/10 text-white/60 hover:text-white transition",
                children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex-1 overflow-y-auto no-scrollbar p-4 space-y-6", children: [
            user ? /* @__PURE__ */ jsxs("div", { className: "glass p-4 rounded-2xl flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(Flag, { code: profile?.country_code || "cr", size: 42, className: "ring-2 ring-primary/30" }),
              /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsx("span", { className: "block font-semibold text-white truncate leading-tight", children: profile?.full_name || user.email?.split("@")[0] }),
                /* @__PURE__ */ jsxs("span", { className: "block text-[11px] text-white/50 truncate", children: [
                  "@",
                  profile?.username || "usuario"
                ] })
              ] }),
              /* @__PURE__ */ jsx(Link, { to: "/profile", onClick: onClose, className: "text-primary hover:text-primary-foreground p-1 transition", children: /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4" }) })
            ] }) : /* @__PURE__ */ jsxs("div", { className: "glass p-4 rounded-2xl text-center", children: [
              /* @__PURE__ */ jsx("span", { className: "font-display text-base text-white block", children: "Participa en la Quiniela" }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-white/50 mt-1", children: "Guarda tus pronósticos en tiempo real y entra al ranking." }),
              /* @__PURE__ */ jsx(
                Link,
                {
                  to: "/profile",
                  onClick: onClose,
                  className: "mt-3 block w-full rounded-xl bg-primary py-2 text-center text-xs font-bold uppercase tracking-wider text-primary-foreground transition active:scale-95",
                  children: "Iniciar Sesión"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsx("span", { className: "px-2 text-[9px] font-bold uppercase tracking-[0.2em] text-white/30 block mb-2", children: "Navegación" }),
              navItems.map((item) => /* @__PURE__ */ jsxs(
                Link,
                {
                  to: item.to,
                  onClick: onClose,
                  className: `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition hover:bg-white/5 ${item.isSpecial ? "text-gradient-gold" : "text-white/80 hover:text-white"}`,
                  children: [
                    /* @__PURE__ */ jsx(item.Icon, { className: `h-4.5 w-4.5 ${item.isSpecial ? "text-[oklch(0.85_0.16_85)]" : "text-white/50"}` }),
                    item.label
                  ]
                },
                item.to
              ))
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsx("span", { className: "px-2 text-[9px] font-bold uppercase tracking-[0.2em] text-white/30 block mb-2", children: "Campeonato Nacional" }),
              /* @__PURE__ */ jsxs(
                Link,
                {
                  to: "/profile",
                  onClick: onClose,
                  className: "flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-semibold text-white/80 hover:text-white transition hover:bg-white/5",
                  children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                      /* @__PURE__ */ jsx(Trophy, { className: "h-4.5 w-4.5 text-white/50" }),
                      /* @__PURE__ */ jsx("span", { children: "Predicción Nacional" })
                    ] }),
                    /* @__PURE__ */ jsx("span", { className: "text-[8px] uppercase tracking-widest bg-primary/10 text-primary px-2 py-0.5 rounded-md font-extrabold", children: "Próximamente" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsx("span", { className: "px-2 text-[9px] font-bold uppercase tracking-[0.2em] text-white/30 block mb-2", children: "Reglamento y Ayuda" }),
              legalItems.map((item) => /* @__PURE__ */ jsxs(
                Link,
                {
                  to: item.to,
                  search: item.search,
                  onClick: onClose,
                  className: "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-white/80 hover:text-white transition hover:bg-white/5",
                  children: [
                    /* @__PURE__ */ jsx(item.Icon, { className: "h-4.5 w-4.5 text-white/50" }),
                    item.label
                  ]
                },
                item.label
              ))
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsx("span", { className: "px-2 text-[9px] font-bold uppercase tracking-[0.2em] text-white/30 block mb-2", children: "Configuración" }),
              /* @__PURE__ */ jsxs(
                Link,
                {
                  to: "/profile",
                  onClick: onClose,
                  className: "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-white/80 hover:text-white transition hover:bg-white/5",
                  children: [
                    /* @__PURE__ */ jsx(Settings, { className: "h-4.5 w-4.5 text-white/50" }),
                    /* @__PURE__ */ jsx("span", { children: "Configuración de la app" })
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "p-4 border-t border-white/10", children: user ? /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: handleLogout,
              className: "flex w-full items-center justify-center gap-2 rounded-xl bg-red-500/10 border border-red-500/20 py-2.5 text-sm font-bold uppercase tracking-wider text-red-400 hover:bg-red-500 hover:text-white transition",
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "h-4 w-4" }),
                " Cerrar Sesión"
              ]
            }
          ) : /* @__PURE__ */ jsx("div", { className: "text-center text-[10px] text-white/30", children: "Golazo Quiniela © 2026" }) })
        ]
      }
    )
  ] });
}
function AppShell({ children }) {
  const { isOpen, close } = useSidebar();
  return /* @__PURE__ */ jsxs("div", { className: "relative mx-auto min-h-screen w-full max-w-md", children: [
    /* @__PURE__ */ jsxs("div", { "aria-hidden": true, className: "pointer-events-none fixed inset-0 -z-10 overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute -top-40 left-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-primary/20 blur-[120px]" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-0 right-[-80px] h-[300px] w-[300px] rounded-full bg-[oklch(0.6_0.22_260/0.18)] blur-[100px]" })
    ] }),
    /* @__PURE__ */ jsx("main", { className: "pb-32", children }),
    /* @__PURE__ */ jsx(BottomNav, {}),
    /* @__PURE__ */ jsx(Sidebar, { isOpen, onClose: close })
  ] });
}
export {
  AppShell as A,
  Flag as F,
  groups as a,
  getDynamicLeaderboard as b,
  calculateUserStats as c,
  calculateMatchPoints as d,
  isPredictionCorrect as e,
  teamByCode as f,
  getSupabaseLeaderboard as g,
  matchesByGroup as h,
  isPredictionExact as i,
  matchesByStage as j,
  useChampion as k,
  leaderboard as l,
  matches as m,
  nextMatch as n,
  upcomingMatches as o,
  predictionsStore as p,
  supabase as s,
  teams as t,
  useAuth as u
};
